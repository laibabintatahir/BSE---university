import { useState } from "react";
import { ModuleType } from "@/components/Teacher/ModuleList";

export function useModules() {
  const [modules, setModules] = useState<ModuleType[]>([]);

  const addModule = (type: "text" | "video" | "quiz") => {
    const newModule: ModuleType = {
      id: Date.now().toString(),
      title: `New ${type.charAt(0).toUpperCase() + type.slice(1)} Module`,
      content: "",
      type,
    };
    setModules([...modules, newModule]);
  };

  const updateModule = (id: string, field: keyof ModuleType, value: string) => {
    setModules(
      modules.map((module) =>
        module.id === id ? { ...module, [field]: value } : module
      )
    );
  };

  const moveModule = (id: string, direction: "up" | "down") => {
    const index = modules.findIndex((module) => module.id === id);
    if (
      (direction === "up" && index > 0) ||
      (direction === "down" && index < modules.length - 1)
    ) {
      const newModules = [...modules];
      const [movedModule] = newModules.splice(index, 1);
      newModules.splice(
        direction === "up" ? index - 1 : index + 1,
        0,
        movedModule
      );
      setModules(newModules);
    }
  };

  return { modules, addModule, updateModule, moveModule };
}
