import { useState } from "react";
import { ModuleType } from "@/components/Teacher/ModuleList";

interface LectureDetails {
  title: string;
  topic: string;
  learningOutcomes: string;
  description: string;
}

export function useLectureGeneration(
  modules: ModuleType[],
  updateModule: (id: string, field: keyof ModuleType, value: string) => void
) {
  const [lectureDetails, setLectureDetails] = useState<LectureDetails>({
    title: "",
    topic: "",
    learningOutcomes: "",
    description: "",
  });
  const [referenceFiles, setReferenceFiles] = useState<File[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [effectivenessScore, setEffectivenessScore] = useState(0);

  const generateContent = async () => {
    setIsGenerating(true);

    try {
      const formData = new FormData();
      Object.entries(lectureDetails).forEach(([key, value]) => {
        formData.append(key, value);
      });
      referenceFiles.forEach((file) => {
        formData.append("referenceFiles", file);
      });

      const response = await fetch("http://localhost:8000/lecture/generate", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to generate lecture content.");
      }

      const data = await response.json();

      data.content.forEach((module: ModuleType) => {
        if (modules.some((m) => m.id === module.id)) {
          updateModule(module.id, "content", module.content);
        } else {
          updateModule(module.id, "title", module.title || "Untitled Module");
          updateModule(module.id, "content", module.content || "");
          updateModule(module.id, "type", module.type || "text");
        }
      });

      if (data.effectivenessScore) {
        setEffectivenessScore(data.effectivenessScore);
      }
    } catch (error) {
      console.error("Error generating content:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return {
    lectureDetails,
    setLectureDetails,
    referenceFiles,
    setReferenceFiles,
    generateContent,
    isGenerating,
    effectivenessScore,
  };
}
