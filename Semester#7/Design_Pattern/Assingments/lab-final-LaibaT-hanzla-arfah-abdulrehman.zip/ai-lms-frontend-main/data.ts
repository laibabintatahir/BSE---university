export const courses = [
    { id: "web-dev", name: "Web Development" },
    { id: "db-sys", name: "Database Systems" },
    { id: "ai-ml", name: "AI & Machine Learning" },
    { id: "mobile-dev", name: "Mobile Development" },
    { id: "cloud-comp", name: "Cloud Computing" }
  ] as const
  
  