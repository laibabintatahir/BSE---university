"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Status } from "@/types"

interface Question {
  id: string
  text: string
  type: "mcq" | "fitb" | "short"
  answer: string
  correctAnswer: string
  marks: number
  isCorrect: boolean
}

interface Submission {
  id: string
  studentName: string
  registrationNumber: string
  obtainedMarks: number
  totalMarks: number
  status: Status
}

interface QuizSubmissionViewProps {
  submission: Submission
  onClose: () => void
  onSave: (updatedSubmission: Submission) => void
}

export function QuizSubmissionView({ submission, onClose, onSave }: QuizSubmissionViewProps) {
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: "1",
      text: "What is React?",
      type: "mcq",
      answer: "A JavaScript library for building user interfaces",
      correctAnswer: "A JavaScript library for building user interfaces",
      marks: 5,
      isCorrect: true,
    },
    {
      id: "2",
      text: "What does JSX stand for?",
      type: "short",
      answer: "JavaScript XML",
      correctAnswer: "JavaScript XML",
      marks: 5,
      isCorrect: true,
    },
  ])

  const handleMarkChange = (questionId: string, isCorrect: boolean) => {
    setQuestions(questions.map(q => 
      q.id === questionId ? { ...q, isCorrect } : q
    ))
  }

  const handleSave = () => {
    const updatedObtainedMarks = questions.reduce((total, q) => total + (q.isCorrect ? q.marks : 0), 0)
    const updatedSubmission = { ...submission, obtainedMarks: updatedObtainedMarks }
    onSave(updatedSubmission)
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Quiz Submission - {submission.studentName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 max-h-[60vh] overflow-y-auto">
          {questions.map((question) => (
            <div key={question.id} className="border p-4 rounded-md">
              <h3 className="font-semibold mb-2">{question.text}</h3>
              <p className="mb-2">Student's Answer: {question.answer}</p>
              <p className="mb-2">Correct Answer: {question.correctAnswer}</p>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id={`correct-${question.id}`}
                  checked={question.isCorrect}
                  onCheckedChange={(checked) => handleMarkChange(question.id, checked as boolean)}
                />
                <label htmlFor={`correct-${question.id}`}>Marked Correct</label>
              </div>
              <Input 
                type="number" 
                value={question.marks} 
                onChange={(e) => {
                  const newMarks = Number(e.target.value)
                  setQuestions(questions.map(q => 
                    q.id === question.id ? { ...q, marks: newMarks } : q
                  ))
                }}
                className="w-20 mt-2"
              />
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button onClick={onClose} variant="outline">Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

