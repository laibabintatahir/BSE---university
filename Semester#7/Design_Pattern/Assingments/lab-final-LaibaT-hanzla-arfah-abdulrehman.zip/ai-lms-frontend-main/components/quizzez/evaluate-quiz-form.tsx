"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { StatusBadge } from "../ui/status-badge"
import { QuizSubmissionView } from "../quizzez/quiz-submission-view"
import { Status } from "@/types"
import { Users, Clock, BarChart, Eye } from 'lucide-react'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts'

interface Submission {
  id: string
  studentName: string
  registrationNumber: string
  obtainedMarks: number
  totalMarks: number
  status: Status
  submissionTime: string
  timeTaken: number
}

interface EvaluateQuizFormProps {
  quizId: string
}

export function EvaluateQuizForm({ quizId }: EvaluateQuizFormProps) {
  const router = useRouter()
  const [submissions, setSubmissions] = useState<Submission[]>([
    {
      id: "1",
      studentName: "John Doe",
      registrationNumber: "2023-CS-123",
      obtainedMarks: 85,
      totalMarks: 100,
      status: "ai-graded",
      submissionTime: "2023-05-15 14:30",
      timeTaken: 45
    },
    {
      id: "2",
      studentName: "Jane Smith",
      registrationNumber: "2023-CS-124",
      obtainedMarks: 92,
      totalMarks: 100,
      status: "graded",
      submissionTime: "2023-05-15 15:45",
      timeTaken: 38
    },
    // Add more mock data here
  ])
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null)

  const handleMarksChange = (id: string, field: 'obtainedMarks' | 'totalMarks', value: number) => {
    setSubmissions(submissions.map(sub =>
      sub.id === id ? { ...sub, [field]: value } : sub
    ))
  }

  const handleSaveChanges = () => {
    // Here you would typically save the changes to your backend
    console.log("Saving changes:", submissions)
  }

  const averageScore = submissions.reduce((sum, sub) => sum + sub.obtainedMarks, 0) / submissions.length
  const averageTime = submissions.reduce((sum, sub) => sum + sub.timeTaken, 0) / submissions.length

  const scoreDistribution = [
    { name: '90-100', value: submissions.filter(s => s.obtainedMarks >= 90).length },
    { name: '80-89', value: submissions.filter(s => s.obtainedMarks >= 80 && s.obtainedMarks < 90).length },
    { name: '70-79', value: submissions.filter(s => s.obtainedMarks >= 70 && s.obtainedMarks < 80).length },
    { name: '60-69', value: submissions.filter(s => s.obtainedMarks >= 60 && s.obtainedMarks < 70).length },
    { name: '<60', value: submissions.filter(s => s.obtainedMarks < 60).length },
  ]

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8']

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Quiz Info</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <div>
                <h3 className="text-sm font-medium">Total Submissions</h3>
                <p className="text-2xl font-bold">{submissions.length}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <BarChart className="h-4 w-4 text-muted-foreground" />
              <div>
                <h3 className="text-sm font-medium">Average Score</h3>
                <p className="text-2xl font-bold">{averageScore.toFixed(2)}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div>
                <h3 className="text-sm font-medium">Average Time</h3>
                <p className="text-2xl font-bold">{averageTime.toFixed(2)} min</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Eye className="h-4 w-4 text-muted-foreground" />
              <div>
                <h3 className="text-sm font-medium">Pending Review</h3>
                <p className="text-2xl font-bold">{submissions.filter(s => s.status === 'pending').length}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Score Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={scoreDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {scoreDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Submissions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-end space-x-4 mb-4">
            <Button onClick={handleSaveChanges}>
              Save Changes
            </Button>
            <Button>
              AI Evaluate All
            </Button>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Reg #</TableHead>
                <TableHead>Obtained</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Submission Time</TableHead>
                <TableHead>Time Taken</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {submissions.map((submission) => (
                <TableRow key={submission.id}>
                  <TableCell>{submission.studentName}</TableCell>
                  <TableCell>{submission.registrationNumber}</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={submission.obtainedMarks}
                      onChange={(e) => handleMarksChange(submission.id, 'obtainedMarks', Number(e.target.value))}
                      className="w-20"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={submission.totalMarks}
                      onChange={(e) => handleMarksChange(submission.id, 'totalMarks', Number(e.target.value))}
                      className="w-20"
                    />
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={submission.status} />
                  </TableCell>
                  <TableCell>{submission.submissionTime}</TableCell>
                  <TableCell>{submission.timeTaken} min</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => setSelectedSubmission(submission)}>
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {selectedSubmission && (
        <QuizSubmissionView
          submission={selectedSubmission}
          onClose={() => setSelectedSubmission(null)}
          onSave={(updatedSubmission) => {
            setSubmissions(submissions.map(sub =>
              sub.id === updatedSubmission.id ? updatedSubmission : sub
            ))
            setSelectedSubmission(null)
          }}
        />
      )}
    </div>
  )
}

