"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { format } from "date-fns"
import { CalendarIcon, Plus, X } from 'lucide-react'

const courses = [
  { id: "web-dev", name: "Web Development" },
  { id: "db-sys", name: "Database Systems" },
  { id: "ai-ml", name: "AI & Machine Learning" },
]

interface Question {
  id: string
  text: string
  type: "mcq" | "fitb" | "short"
  options?: string[]
  correctAnswer?: string
}

export function CreateQuizForm() {
  const router = useRouter()
  const [dueDate, setDueDate] = useState<Date>()
  const [aiGrading, setAiGrading] = useState(false)
  const [questionTypes, setQuestionTypes] = useState({
    mcq: false,
    fitb: false,
    short: false,
  })
  const [selectedCourse, setSelectedCourse] = useState("")
  const [questions, setQuestions] = useState<Question[]>([])
  const [newQuestion, setNewQuestion] = useState<Question>({
    id: "",
    text: "",
    type: "mcq",
    options: ["", ""],
    correctAnswer: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log("Quiz data:", { selectedCourse, dueDate, aiGrading, questions })
    router.push("/quizzes")
  }

  const addQuestion = () => {
    setQuestions([...questions, { ...newQuestion, id: Date.now().toString() }])
    setNewQuestion({
      id: "",
      text: "",
      type: "mcq",
      options: ["", ""],
      correctAnswer: "",
    })
  }

  const removeQuestion = (id: string) => {
    setQuestions(questions.filter(q => q.id !== id))
  }

  return (
    <Card>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="course">Course</Label>
            <Select value={selectedCourse} onValueChange={setSelectedCourse}>
              <SelectTrigger>
                <SelectValue placeholder="Select a course" />
              </SelectTrigger>
              <SelectContent>
                {courses.map((course) => (
                  <SelectItem key={course.id} value={course.id}>
                    {course.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Quiz Title</Label>
            <Input id="title" placeholder="Enter quiz title" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="dueDate">Due Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dueDate ? format(dueDate, "PPP") : "Select due date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={dueDate}
                  onSelect={setDueDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="ai-grading"
              checked={aiGrading}
              onCheckedChange={setAiGrading}
            />
            <Label htmlFor="ai-grading">Enable AI Grading</Label>
          </div>

          <div className="space-y-2">
            <Label>Question Types</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="mcq"
                  checked={questionTypes.mcq}
                  onCheckedChange={(checked) => 
                    setQuestionTypes(prev => ({ ...prev, mcq: checked as boolean }))
                  }
                />
                <Label htmlFor="mcq">Multiple Choice Questions</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="fitb"
                  checked={questionTypes.fitb}
                  onCheckedChange={(checked) => 
                    setQuestionTypes(prev => ({ ...prev, fitb: checked as boolean }))
                  }
                />
                <Label htmlFor="fitb">Fill in the Blanks</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="short"
                  checked={questionTypes.short}
                  onCheckedChange={(checked) => 
                    setQuestionTypes(prev => ({ ...prev, short: checked as boolean }))
                  }
                />
                <Label htmlFor="short">Short Questions</Label>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <Label>Add New Question</Label>
            <Select value={newQuestion.type} onValueChange={(value) => setNewQuestion({ ...newQuestion, type: value as "mcq" | "fitb" | "short" })}>
              <SelectTrigger>
                <SelectValue placeholder="Select question type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mcq">Multiple Choice</SelectItem>
                <SelectItem value="fitb">Fill in the Blank</SelectItem>
                <SelectItem value="short">Short Answer</SelectItem>
              </SelectContent>
            </Select>
            <Input
              placeholder="Enter question text"
              value={newQuestion.text}
              onChange={(e) => setNewQuestion({ ...newQuestion, text: e.target.value })}
            />
            {newQuestion.type === "mcq" && (
              <div className="space-y-2">
                {newQuestion.options?.map((option, index) => (
                  <Input
                    key={index}
                    placeholder={`Option ${index + 1}`}
                    value={option}
                    onChange={(e) => {
                      const newOptions = [...(newQuestion.options || [])]
                      newOptions[index] = e.target.value
                      setNewQuestion({ ...newQuestion, options: newOptions })
                    }}
                  />
                ))}
                <Button type="button" onClick={() => setNewQuestion({ ...newQuestion, options: [...(newQuestion.options || []), ""] })}>
                  Add Option
                </Button>
              </div>
            )}
            {(newQuestion.type === "mcq" || newQuestion.type === "fitb") && (
              <Input
                placeholder="Correct Answer"
                value={newQuestion.correctAnswer}
                onChange={(e) => setNewQuestion({ ...newQuestion, correctAnswer: e.target.value })}
              />
            )}
            <Button type="button" onClick={addQuestion}>Add Question</Button>
          </div>

          <div className="space-y-4">
            <Label>Added Questions</Label>
            {questions.map((question, index) => (
              <div key={question.id} className="border p-4 rounded-md relative">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() => removeQuestion(question.id)}
                >
                  <X className="h-4 w-4" />
                </Button>
                <p className="font-semibold">Question {index + 1}: {question.text}</p>
                <p>Type: {question.type}</p>
                {question.type === "mcq" && (
                  <div>
                    <p>Options:</p>
                    <ul className="list-disc list-inside">
                      {question.options?.map((option, optionIndex) => (
                        <li key={optionIndex}>{option}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {(question.type === "mcq" || question.type === "fitb") && (
                  <p>Correct Answer: {question.correctAnswer}</p>
                )}
              </div>
            ))}
          </div>

          <div className="flex justify-end space-x-4">
            <Button variant="outline" type="button" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit">Save & Publish</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

    