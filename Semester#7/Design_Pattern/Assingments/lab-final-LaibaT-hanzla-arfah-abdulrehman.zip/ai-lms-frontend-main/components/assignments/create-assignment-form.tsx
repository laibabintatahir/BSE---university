"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Card,
  CardContent,
} from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon } from 'lucide-react'

export function CreateAssignmentForm() {
  const router = useRouter()
  const [dueDate, setDueDate] = useState<Date>()
  const [aiGrading, setAiGrading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    router.push("/assignments")
  }

  return (
    <Card>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="course">Course</Label>
            <Input id="course" placeholder="Enter course name" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Assignment Name</Label>
            <Input id="name" placeholder="Enter assignment name" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="dueDate">Due Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dueDate ? format(dueDate, "PPP") : "Select due date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={dueDate}
                  onSelect={setDueDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="ai-grading"
              checked={aiGrading}
              onCheckedChange={setAiGrading}
            />
            <Label htmlFor="ai-grading">Enable AI Grading</Label>
          </div>

          <div className="space-y-2">
            <Label htmlFor="rubrics">Rubrics</Label>
            <Textarea 
              id="rubrics" 
              placeholder="Enter grading rubrics (one per line)"
              className="min-h-[100px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Assignment Content</Label>
            <Textarea 
              id="content" 
              placeholder="Enter assignment details and instructions"
              className="min-h-[200px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="file">Upload Files</Label>
            <Input id="file" type="file" />
          </div>

          <div className="flex justify-end space-x-4">
            <Button variant="outline" type="button" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit">Save & Publish</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

