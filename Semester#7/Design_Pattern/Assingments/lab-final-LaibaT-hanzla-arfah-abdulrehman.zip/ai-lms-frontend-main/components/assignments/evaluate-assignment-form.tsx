"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { StatusBadge } from "../ui/status-badge"
import { Download, FileText, Users, Clock, BarChart } from 'lucide-react'
import { Status } from "@/types"
import { Label } from "../ui/label"
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface Submission {
  id: string
  studentName: string
  registrationNumber: string
  obtainedMarks: number
  totalMarks: number
  status: Status
  file: string
  feedback: string
  submissionTime: string
}

interface EvaluateAssignmentFormProps {
  assignmentId: string
}

export function EvaluateAssignmentForm({ assignmentId }: EvaluateAssignmentFormProps) {
  const router = useRouter()
  const [submissions, setSubmissions] = useState<Submission[]>([
    {
      id: "1",
      studentName: "John Doe",
      registrationNumber: "2023-CS-123",
      obtainedMarks: 85,
      totalMarks: 100,
      status: "ai-graded",
      file: "assignment1.pdf",
      feedback: "Good work overall. Could improve on code organization.",
      submissionTime: "2023-05-15 14:30"
    },
    {
      id: "2",
      studentName: "Jane Smith",
      registrationNumber: "2023-CS-124",
      obtainedMarks: 92,
      totalMarks: 100,
      status: "graded",
      file: "assignment2.pdf",
      feedback: "Excellent submission. Well-structured and documented.",
      submissionTime: "2023-05-15 15:45"
    },
    // Add more mock data here
  ])

  const handleMarksChange = (id: string, field: 'obtainedMarks' | 'totalMarks', value: number) => {
    setSubmissions(submissions.map(sub =>
      sub.id === id ? { ...sub, [field]: value } : sub
    ))
  }

  const handleFeedbackChange = (id: string, feedback: string) => {
    setSubmissions(submissions.map(sub =>
      sub.id === id ? { ...sub, feedback } : sub
    ))
  }

  const handleSaveChanges = () => {
    // Here you would typically save the changes to your backend
    console.log("Saving changes:", submissions)
  }

  const gradeDistribution = [
    { grade: 'A', count: submissions.filter(s => s.obtainedMarks >= 90).length },
    { grade: 'B', count: submissions.filter(s => s.obtainedMarks >= 80 && s.obtainedMarks < 90).length },
    { grade: 'C', count: submissions.filter(s => s.obtainedMarks >= 70 && s.obtainedMarks < 80).length },
    { grade: 'D', count: submissions.filter(s => s.obtainedMarks >= 60 && s.obtainedMarks < 70).length },
    { grade: 'F', count: submissions.filter(s => s.obtainedMarks < 60).length },
  ]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Assignment Info</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <div>
                <h3 className="text-sm font-medium">Total Submissions</h3>
                <p className="text-2xl font-bold">{submissions.length}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <div>
                <h3 className="text-sm font-medium">Graded</h3>
                <p className="text-2xl font-bold">{submissions.filter(s => s.status === 'graded').length}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div>
                <h3 className="text-sm font-medium">Due Date</h3>
                <p className="text-2xl font-bold">May 20, 2023</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <BarChart className="h-4 w-4 text-muted-foreground" />
              <div>
                <h3 className="text-sm font-medium">Average Score</h3>
                <p className="text-2xl font-bold">
                  {(submissions.reduce((sum, sub) => sum + sub.obtainedMarks, 0) / submissions.length).toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Grade Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <RechartsBarChart data={gradeDistribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="grade" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#8884d8" />
            </RechartsBarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Submissions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-end space-x-4 mb-4">
            <Button onClick={handleSaveChanges}>
              Save Changes
            </Button>
            <Button>
              AI Evaluate All
            </Button>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Reg #</TableHead>
                <TableHead>Obtained</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Submission Time</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {submissions.map((submission) => (
                <TableRow key={submission.id}>
                  <TableCell>{submission.studentName}</TableCell>
                  <TableCell>{submission.registrationNumber}</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={submission.obtainedMarks}
                      onChange={(e) => handleMarksChange(submission.id, 'obtainedMarks', Number(e.target.value))}
                      className="w-20"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={submission.totalMarks}
                      onChange={(e) => handleMarksChange(submission.id, 'totalMarks', Number(e.target.value))}
                      className="w-20"
                    />
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={submission.status} />
                  </TableCell>
                  <TableCell>{submission.submissionTime}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon">
                      <Download className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

