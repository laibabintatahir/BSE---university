"use client"

import { Assignment } from "@/types"
import { StatusBadge} from "../ui/status-badge"
import { ActionDropdown } from "../ui/action-dropdown"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import Link from "next/link"

interface AssignmentCardProps {
  assignment: Assignment
  onAction: (action: any) => void
}

export function AssignmentCard({ assignment, onAction }: AssignmentCardProps) {
  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <StatusBadge status={assignment.status} />
        <ActionDropdown onAction={onAction} />
      </CardHeader>
      <CardContent>
        <h3 className="font-semibold mb-2">{assignment.title}</h3>
        <div className="flex flex-col space-y-2">
          <p className="text-sm text-muted-foreground">
            Course: {assignment.course}
          </p>
          <p className="text-sm text-muted-foreground">
            Due: {new Date(assignment.dueDate).toLocaleDateString()}
          </p>
          <Link 
            href={`/assignments/${assignment.id}/${ 'evaluate'}`}
          >
            <Button className="w-full">
              {assignment.status === 'ungraded' ? 'Evaluate' : 'View'}
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}

