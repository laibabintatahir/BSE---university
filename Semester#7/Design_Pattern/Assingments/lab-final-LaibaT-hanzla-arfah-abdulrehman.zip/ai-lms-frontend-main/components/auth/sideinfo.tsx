import React from 'react';
import { GraduationCap, Users, ClipboardCheck, Lightbulb, LineChart } from 'lucide-react';

const SideInfo = ({ children }: { children: React.ReactNode }) => {
    return (
        <div className="flex lg:flex-row flex-col min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
            <div className="hidden lg:flex w-1/2 bg-cover bg-center relative overflow-hidden">
                <div className="absolute inset-0 bg-primary/90 backdrop-blur-sm"></div>
                <div className="relative flex flex-col justify-center px-12 py-20 text-white h-full w-full z-10">
                    <div className="mb-12">
                        <h1 className="text-5xl font-extrabold mb-2 tracking-tight">
                            ClassEdge LMS
                        </h1>
                        <h2 className="text-xl font-light">
                            AI-Assisted LMS, providing a personalized learning experience
                        </h2>
                    </div>
                    <ul className="space-y-6 text-lg mb-12">
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <GraduationCap className="w-6 h-6 text-primary" />
                            </div>
                            <span>Track student progress with detailed analytics and insights</span>
                        </li>
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <Users className="w-6 h-6 text-primary" />
                            </div>
                            <span>Collaborate effectively with students and educators through an intuitive interface</span>
                        </li>
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <ClipboardCheck className="w-6 h-6 text-primary" />
                            </div>
                            <span>Seamlessly manage assignments, quizzes, and assessments</span>
                        </li>
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <Lightbulb className="w-6 h-6 text-primary" />
                            </div>
                            <span>Encourage creative learning through AI-driven recommendations</span>
                        </li>
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <LineChart className="w-6 h-6 text-primary" />
                            </div>
                            <span>Visualize institutional performance through interactive dashboards</span>
                        </li>
                    </ul>
                    <div className="mt-auto">
                        <blockquote className="text-2xl font-serif italic">
                            "Education is not the filling of a pail, but the lighting of a fire."
                        </blockquote>
                        <cite className="block mt-2 text-right text-blue-300">~ Laiba Binta Tahir</cite>
                    </div>
                </div>
            </div>

            {/* For Mobile View */}
            <div className="lg:hidden flex flex-col items-center justify-center w-full px-4 py-8">
                <h1 className="text-3xl font-extrabold mb-2 tracking-tight">Edu Education</h1>
                <h2 className="text-xl font-light italic">AI-Assisted LMS</h2>
            </div>
            {children}
        </div>
    );
};

export default SideInfo;
