'use client'

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { signIn } from 'next-auth/react'

import { Button } from "@/components/ui/button"
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'react-hot-toast'
export function AdminAuthForm() {
    const [isFlipping, setIsFlipping] = useState(false)
    const [loading, setLoading] = useState(false)
    const [formData, setFormData] = useState({ email: '', regNo: '', password: '' })
    const [errors, setErrors] = useState<{ [key: string]: string }>({})

    const router = useRouter()

    const validateForm = () => {
        const newErrors: { [key: string]: string } = {}


        if (!formData.email) newErrors.email = "Email is required"
        else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = "Invalid email format"


        if (!formData.password) newErrors.password = "Password is required"
        else if (formData.password.length < 6) newErrors.password = "Password must be at least 6 characters"

        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        if (!validateForm()) return

        setLoading(true)
        try {

            const result = await signIn('credentials', {
                email: formData.email,
                userType: 'admin',
                password: formData.password,
                redirect: false,
            })

            if (result?.error) {
                toast.error("Authentication Error")
            } else {
                router.push('/')
            }
        } catch (error) {
            toast.error("An unexpected error occurred. Please try again.")
        } finally {
            setLoading(false)
        }
    }

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target
        setFormData(prev => ({ ...prev, [name]: value }))
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: '' }))
        }
    }

    return (
        <div className="flex items-center justify-center w-full lg:w-1/2 px-4">
            <Card className={`w-full max-w-md transition-transform duration-400 ${isFlipping ? 'scale-95' : 'scale-100'}`}>
                <CardHeader className="space-y-1">
                    <CardTitle className="text-2xl">
                        Admin Sign In
                    </CardTitle>
                    <CardDescription>
                        Sign in to access the admin dashboard
                    </CardDescription>
                </CardHeader>
                <CardContent>



                    <form onSubmit={handleSubmit}>
                        <div className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="email">Email</Label>
                                <Input
                                    id="email"
                                    name="email"
                                    type="email"
                                    placeholder="admin@example.com"
                                    value={formData.email}
                                    onChange={handleInputChange}
                                    aria-invalid={!!errors.email}
                                    aria-describedby={errors.email ? "email-error" : undefined}
                                />
                                {errors.email && <p id="email-error" className="text-xs text-red-500">{errors.email}</p>}
                            </div>
                            <div className="space-y-2">
                                <div className="flex items-center">
                                    <Label htmlFor="teacher-password">Password</Label>

                                </div>
                                <Input
                                    id="teacher-password"
                                    name="password"
                                    type="password"
                                    placeholder="Password"
                                    value={formData.password}
                                    onChange={handleInputChange}
                                    aria-invalid={!!errors.password}
                                    aria-describedby={errors.password ? "password-error" : undefined}
                                />
                                {errors.password && <p id="password-error" className="text-xs text-red-500">{errors.password}</p>}

                            </div>
                            <Button type="submit" className="w-full" disabled={loading}>
                                {loading ?
                                    <svg className="animate-spin h-6 w-6  border-white border-2 rounded-full" viewBox="0 0 24 24"></svg>
                                    : "Sign In"}
                            </Button>
                        </div>
                    </form>



                    <div className="mt-4 relative">
                        <div className="absolute inset-0 flex items-center">
                            <Separator />
                        </div>
                        <div className="relative flex justify-center text-sm uppercase">
                            <span className="bg-background px-6 text-muted-foreground ">
                                OR
                            </span>
                        </div>
                    </div>
                    <div className="mt-4 space-y-2">
                        <Button variant="outline" className="w-full">
                            <Link href="/auth/signin">Sign in to LMS</Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div >
    )
}

