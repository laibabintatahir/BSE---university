import React from 'react';
import { GraduationCap, FileText, Users, Settings, PieChart, BarChart } from 'lucide-react';

const AdminSideInfo = ({ children }: { children: React.ReactNode }) => {
    return (
        <div className="flex lg:flex-row flex-col min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">

            <div className="hidden lg:flex w-1/2 bg-cover bg-center relative overflow-hidden" >
                <div className="absolute inset-0 bg-primary/90 backdrop-blur-sm"></div>
                <div className="relative flex flex-col justify-center px-12 py-20 text-white h-full w-full z-10">
                    <div className="mb-12">
                        <h1 className="text-5xl font-extrabold mb-2 tracking-tight">
                            ClassEdge Admin
                        </h1>
                        <h2 className="text-xl font-italic text-secondary">
                            Manage your learning platform & resources with ease.
                        </h2>
                    </div>
                    <ul className="space-y-6 text-lg mb-12">
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <GraduationCap className="w-6 h-6 text-primary" />
                            </div>
                            <span>Monitor student performance and generate detailed reports</span>
                        </li>
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <FileText className="w-6 h-6 text-primary" />
                            </div>
                            <span>Manage courses, assignments, and assessments</span>
                        </li>

                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <Settings className="w-6 h-6 text-primary" />
                            </div>
                            <span>Configure system settings and customize platform features</span>
                        </li>
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <PieChart className="w-6 h-6 text-primary" />
                            </div>
                            <span>Access analytics to track institutional progress</span>
                        </li>
                        <li className="flex items-center space-x-4">
                            <div className="bg-white p-3 rounded-full">
                                <BarChart className="w-6 h-6 text-primary" />
                            </div>
                            <span>Review and optimize resource allocation</span>
                        </li>
                    </ul>
                    <div className="mt-auto">
                        <blockquote className="text-2xl font-serif italic">
                            "Learning is not the filling of a pail, but the lighting of a fire."
                        </blockquote>
                        <cite className="block mt-2 text-right text-blue-300">~ Arfah Ali
                        </cite>
                    </div>
                </div>
            </div>

            {/* For Mobile View */}
            <div className="lg:hidden flex flex-col items-center justify-center w-full px-4 py-8">
                {/* Add some content, shorter, optimized for mobile */}
                <h1 className="text-3xl font-extrabold mb-2 tracking-tight">Edu Education</h1>
                <h2 className="text-xl font-light italic">AI-Assisted LMS</h2>
            </div>
            {children}
        </div>
    );
};

export default AdminSideInfo;
