import React from 'react';
import { Button } from '@/components/ui/button';
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Bold, Italic, Underline, List, ListOrdered, AlignLeft, AlignCenter, AlignRight } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface NotesEditorProps {
    initialContent: string;
    onChange: (content: string) => void;
    onSave: () => void;
}

const NotesEditor: React.FC<NotesEditorProps> = ({ initialContent, onChange, onSave }) => {
    const execCommand = (command: string, value?: string) => {
        document.execCommand(command, false, value);
    };

    return (
        <div className="border rounded-lg p-4">
            <div className="flex flex-wrap gap-2 p-2 border-b">
                <ToggleGroup type="multiple" className="justify-start">
                    <ToggleGroupItem value="bold" aria-label="Toggle bold" onClick={() => execCommand('bold')}>
                        <Bold className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="italic" aria-label="Toggle italic" onClick={() => execCommand('italic')}>
                        <Italic className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="underline" aria-label="Toggle underline" onClick={() => execCommand('underline')}>
                        <Underline className="h-4 w-4" />
                    </ToggleGroupItem>
                </ToggleGroup>
                <ToggleGroup type="single" className="justify-start">
                    <ToggleGroupItem value="left" aria-label="Align left" onClick={() => execCommand('justifyLeft')}>
                        <AlignLeft className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="center" aria-label="Align center" onClick={() => execCommand('justifyCenter')}>
                        <AlignCenter className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="right" aria-label="Align right" onClick={() => execCommand('justifyRight')}>
                        <AlignRight className="h-4 w-4" />
                    </ToggleGroupItem>
                </ToggleGroup>
                <ToggleGroup type="multiple" className="justify-start">
                    <ToggleGroupItem value="bullet" aria-label="Bullet list" onClick={() => execCommand('insertUnorderedList')}>
                        <List className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="number" aria-label="Numbered list" onClick={() => execCommand('insertOrderedList')}>
                        <ListOrdered className="h-4 w-4" />
                    </ToggleGroupItem>
                </ToggleGroup>
                <Select onValueChange={(value) => execCommand('formatBlock', value)}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Paragraph" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="p">Paragraph</SelectItem>
                        <SelectItem value="h1">Heading 1</SelectItem>
                        <SelectItem value="h2">Heading 2</SelectItem>
                        <SelectItem value="h3">Heading 3</SelectItem>
                        <SelectItem value="h4">Heading 4</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <div
                className="p-4 border min-h-[300px] max-h-[500px] overflow-y-auto"
                contentEditable
                dangerouslySetInnerHTML={{ __html: initialContent }}
                onInput={(e) => onChange(e.currentTarget.innerHTML)}
            />
            <div className="flex justify-end mt-3">
                <Button onClick={onSave}>Save Notes</Button>
            </div>
        </div>
    );
};

export default NotesEditor;

