import React from 'react'
import { Loader2, Wand2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface LectureFormProps {
    lectureDetails: {
        title: string
        topic: string
        learningOutcomes: string
        description: string
    }
    setLectureDetails: React.Dispatch<React.SetStateAction<{
        title: string
        topic: string
        learningOutcomes: string
        description: string
    }>>
    referenceFiles: File[]
    setReferenceFiles: React.Dispatch<React.SetStateAction<File[]>>
    generateContent: () => Promise<void>
    isGenerating: boolean
}

export function LectureForm({
    lectureDetails,
    setLectureDetails,
    referenceFiles,
    setReferenceFiles,
    generateContent,
    isGenerating
}: LectureFormProps) {
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target
        setLectureDetails(prev => ({ ...prev, [name]: value }))
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>Lecture Details</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {Object.entries(lectureDetails).map(([key, value]) => (
                        <div key={key} className="space-y-2">
                            <Label htmlFor={key}>{key.charAt(0).toUpperCase() + key.slice(1)}</Label>
                            {key === 'description' || key === 'learningOutcomes' ? (
                                <Textarea
                                    id={key}
                                    name={key}
                                    value={value}
                                    onChange={handleInputChange}
                                    placeholder={`Enter ${key}`}
                                />
                            ) : (
                                <Input
                                    id={key}
                                    name={key}
                                    value={value}
                                    onChange={handleInputChange}
                                    placeholder={`Enter ${key}`}
                                />
                            )}
                        </div>
                    ))}
                    <div className="space-y-2">
                        <Label htmlFor="references">Reference Files</Label>
                        <Input
                            id="references"
                            type="file"
                            multiple
                            onChange={(e) => setReferenceFiles(Array.from(e.target.files || []))}
                        />
                    </div>
                    <Button onClick={generateContent} disabled={isGenerating}>
                        {isGenerating ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Generating...
                            </>
                        ) : (
                            <>
                                <Wand2 className="mr-2 h-4 w-4" />
                                Generate Content
                            </>
                        )}
                    </Button>
                </div>
            </CardContent>
        </Card>
    )
}

