'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from '@/components/ui/context-menu';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { MessageCircle, BookOpen, FileText, Download, Bookmark, Share2, Highlighter } from 'lucide-react';
import NotesEditor from '@/components/notes-editor';
import ChatBot from '@/components/chatbot';
import { marked } from 'marked';
import { jsPDF } from "jspdf";

interface Lecture {
  id: string;
  title: string;
  topic: string;
  description: string;
  learningOutcomes: string;
  modules: {
    title: string;
    content: string;
  }[];
}

export default function LectureView({ params }: { params: { id: string; lectureId: string } }) {
  const router = useRouter();
  const [lecture, setLecture] = useState<Lecture | null>(null);
  const [notes, setNotes] = useState<string>('');
  const [selectedText, setSelectedText] = useState<string>('');
  const [highlights, setHighlights] = useState<string[]>([]);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchLecture = async () => {
      try {
        const response = await fetch(`http://localhost:8000/lecture/${params.lectureId}`);
        if (!response.ok) {
          throw new Error('Failed to fetch lecture');
        }
        const data = await response.json();
        setLecture(data.data);
      } catch (error) {
        console.error('Error fetching lecture:', error);
      }
    };

    fetchLecture();

    const savedNotes = localStorage.getItem(`notes-${params.lectureId}`);
    if (savedNotes) setNotes(savedNotes);

    const savedHighlights = localStorage.getItem(`highlights-${params.lectureId}`);
    if (savedHighlights) setHighlights(JSON.parse(savedHighlights));
  }, [params.lectureId]);

  const saveNotes = () => {
    localStorage.setItem(`notes-${params.lectureId}`, notes);
    alert('Notes saved successfully!');
  };

  const handleTextSelection = () => {
    const selection = window.getSelection();
    if (selection && selection.toString().length > 0) {
      setSelectedText(selection.toString());
    }
  };

  const addHighlight = () => {
    if (selectedText) {
      const newHighlights = [...highlights, selectedText];
      setHighlights(newHighlights);
      localStorage.setItem(`highlights-${params.lectureId}`, JSON.stringify(newHighlights));
    }
  };

  const downloadPDF = async () => {
    if (!lecture) return;

    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text(lecture.title, 20, 20);
    doc.setFontSize(12);
    const description = await marked(lecture.description);
    doc.html(description, {
      callback: function () {
        for (const module of lecture.modules) {
          doc.addPage();
          doc.setFontSize(16);
          doc.text(module.title, 20, 20);
          doc.setFontSize(12);
          doc.html(marked(module.content), {
            callback: function () {
              if (module === lecture.modules[lecture.modules.length - 1]) {
                doc.save(`${lecture.title}.pdf`);
              }
            }
          });
        }
      }
    });
  };

  const shareLecture = () => {
    if (!lecture) return;
    if (navigator.share) {
      navigator.share({
        title: lecture.title,
        text: 'Check out this lecture!',
        url: window.location.href,
      })
        .then(() => console.log('Successful share'))
        .catch((error) => console.log('Error sharing', error));
    } else {
      alert('Web Share API is not supported in your browser');
    }
  };

  if (!lecture) {
    return <p>Loading...</p>;
  }

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold">Lecture: {lecture.title}</h1>
        <div className="flex space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={downloadPDF}>
                  <Download className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Download as PDF</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={shareLecture}>
                  <Share2 className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Share Lecture</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Lecture Content</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[calc(100vh-200px)]">
              <ContextMenu>
                <ContextMenuTrigger>
                  <div
                    ref={contentRef}
                    onMouseUp={handleTextSelection}
                    className="space-y-4"
                  >
                    <p><strong>Topic:</strong> {lecture.topic}</p>
                    <div dangerouslySetInnerHTML={{ __html: marked(lecture.description) }} />
                    <p><strong>Learning Outcomes:</strong></p>
                    <div dangerouslySetInnerHTML={{ __html: marked(lecture.learningOutcomes) }} />
                    <div>
                      <strong>Modules:</strong>
                      {lecture.modules.map((module, index) => (
                        <div key={index} className="mt-4">
                          <h3 className="text-xl font-semibold">{module.title}</h3>
                          <div dangerouslySetInnerHTML={{ __html: marked(module.content) }} />
                        </div>
                      ))}
                    </div>
                  </div>
                </ContextMenuTrigger>
                <ContextMenuContent>
                  <ContextMenuItem onSelect={() => {
                    if (selectedText) {
                      setNotes((prevNotes) => prevNotes + '\n\n' + selectedText);
                    }
                  }}>
                    Add to Notes
                  </ContextMenuItem>
                  <ContextMenuItem onSelect={() => {
                    if (selectedText) {
                      console.log('Asking chatbot about:', selectedText);
                    }
                  }}>
                    Ask Chatbot
                  </ContextMenuItem>
                  <ContextMenuItem onSelect={addHighlight}>
                    Highlight
                  </ContextMenuItem>
                </ContextMenuContent>
              </ContextMenu>
            </ScrollArea>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Tabs defaultValue="notes" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="notes">Notes</TabsTrigger>
              <TabsTrigger value="highlights">Highlights</TabsTrigger>
              <TabsTrigger value="chat">Chat</TabsTrigger>
            </TabsList>
            <TabsContent value="notes">
              <Card>
                <CardContent className="p-4">
                  <NotesEditor
                    initialContent={notes}
                    onChange={setNotes}
                    onSave={saveNotes}
                  />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="highlights">
              <Card>
                <CardContent>
                  <ul className="list-disc pl-4">
                    {highlights.map((highlight, index) => (
                      <li key={index} className="mb-2">{highlight}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="chat">
              <Card>
                <CardContent>
                  <ChatBot lectureId={params.lectureId} />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <Card>
            <CardHeader>
              <CardTitle>Additional Resources</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="flex items-center text-blue-500 hover:underline">
                    <BookOpen className="mr-2 h-4 w-4" />
                    Supplementary Reading
                  </a>
                </li>
                <li>
                  <a href="#" className="flex items-center text-blue-500 hover:underline">
                    <FileText className="mr-2 h-4 w-4" />
                    Practice Exercises
                  </a>
                </li>
                <li>
                  <a href="#" className="flex items-center text-blue-500 hover:underline">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Discussion Forum
                  </a>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

