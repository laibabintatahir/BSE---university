"use client"

import React, { useState, useCallback, useRef } from 'react'
import { Loader2, Plus, Wand2, Bold, Italic, Underline, List, ListOrdered, AlignLeft, AlignCenter, AlignRight, FileText, Trash2 } from 'lucide-react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import toast from "react-hot-toast"
import { useRouter } from "next/navigation"

type ModuleType = {
    id: string
    title: string
    content: string
    type: 'text' | 'video' | 'quiz' | 'file'
    file?: File
    fileContent?: string
}

interface RichTextEditorProps {
    content: string;
    onChange: (content: string) => void;
}

const RichTextEditor: React.FC<RichTextEditorProps> = ({ content, onChange }) => {
    const execCommand = useCallback((command: string, value: string | undefined = undefined) => {
        document.execCommand(command, false, value)
    }, [])

    return (
        <div className="border rounded-md">
            <div className="flex flex-wrap gap-2 p-2 border-b">
                <ToggleGroup type="multiple" className="justify-start">
                    <ToggleGroupItem value="bold" aria-label="Toggle bold" onClick={() => execCommand('bold')}>
                        <Bold className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="italic" aria-label="Toggle italic" onClick={() => execCommand('italic')}>
                        <Italic className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="underline" aria-label="Toggle underline" onClick={() => execCommand('underline')}>
                        <Underline className="h-4 w-4" />
                    </ToggleGroupItem>
                </ToggleGroup>
                <ToggleGroup type="single" className="justify-start">
                    <ToggleGroupItem value="left" aria-label="Align left" onClick={() => execCommand('justifyLeft')}>
                        <AlignLeft className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="center" aria-label="Align center" onClick={() => execCommand('justifyCenter')}>
                        <AlignCenter className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="right" aria-label="Align right" onClick={() => execCommand('justifyRight')}>
                        <AlignRight className="h-4 w-4" />
                    </ToggleGroupItem>
                </ToggleGroup>
                <ToggleGroup type="multiple" className="justify-start">
                    <ToggleGroupItem value="bullet" aria-label="Bullet list" onClick={() => execCommand('insertUnorderedList')}>
                        <List className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="number" aria-label="Numbered list" onClick={() => execCommand('insertOrderedList')}>
                        <ListOrdered className="h-4 w-4" />
                    </ToggleGroupItem>
                </ToggleGroup>
                <Select onValueChange={(value) => execCommand('formatBlock', value)}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Paragraph" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="p">Paragraph</SelectItem>
                        <SelectItem value="h1">Heading 1</SelectItem>
                        <SelectItem value="h2">Heading 2</SelectItem>
                        <SelectItem value="h3">Heading 3</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <div
                className="p-2 min-h-[200px]"
                contentEditable
                dangerouslySetInnerHTML={{ __html: content }}
                onInput={(e) => onChange(e.currentTarget.innerHTML)}
            />
        </div>
    )
}

interface EffectivenessScoreProps {
    score: number
}

function EffectivenessScore({ score }: EffectivenessScoreProps) {
    const clampedScore = Math.max(0, Math.min(100, score))
    const hue = (clampedScore * 120) / 100
    const color = `hsl(${hue}, 100%, 50%)`

    return (
        <Card className="w-64 h-fit sticky top-4">
            <CardHeader>
                <CardTitle>Effectiveness Score</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="flex flex-col items-center">
                    <div className="relative w-32 h-32">
                        <svg className="w-full h-full" viewBox="0 0 100 100">
                            <circle
                                className="text-muted-foreground stroke-current"
                                strokeWidth="10"
                                cx="50"
                                cy="50"
                                r="40"
                                fill="transparent"
                            />
                            <circle
                                stroke={color}
                                strokeWidth="10"
                                strokeLinecap="round"
                                cx="50"
                                cy="50"
                                r="40"
                                fill="transparent"
                                strokeDasharray={`${clampedScore * 2.51327}, 251.327`}
                                transform="rotate(-90 50 50)"
                            />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-2xl font-bold" style={{ color }}>
                                {clampedScore}%
                            </span>
                        </div>
                    </div>
                    <p className="mt-4 text-sm text-muted-foreground">Based on AI analysis</p>
                </div>
            </CardContent>
        </Card>
    )
}

export default function ContentGeneration() {
    const [modules, setModules] = useState<ModuleType[]>([])
    const [title, setTitle] = useState('')
    const [lectureTopic, setLectureTopic] = useState('')
    const [learningOutcomes, setLearningOutcomes] = useState('')
    const [description, setDescription] = useState('')
    const [referenceFiles, setReferenceFiles] = useState<File[]>([])
    const [isGenerating, setIsGenerating] = useState(false)
    const [effectivenessScore, setEffectivenessScore] = useState(19)
    const [draggedModule, setDraggedModule] = useState<ModuleType | null>(null)

    const handleDragStart = (e: React.DragEvent, module: ModuleType) => {
        setDraggedModule(module)
    }

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault()
    }

    const handleDrop = (e: React.DragEvent, targetIndex: number) => {
        e.preventDefault()
        if (draggedModule) {
            const updatedModules = modules.filter(m => m.id !== draggedModule.id)
            updatedModules.splice(targetIndex, 0, draggedModule)
            setModules(updatedModules)
            setDraggedModule(null)
        }
    }

    const addModule = (type: 'text' | 'video' | 'quiz' | 'file') => {
        const newModule: ModuleType = {
            id: Date.now().toString(),
            title: `New ${type.charAt(0).toUpperCase() + type.slice(1)} Module`,
            content: '',
            type,
            fileContent: '',
        }
        setModules([...modules, newModule])
    }

    const updateModule = (id: string, field: keyof ModuleType, value: string | File) => {
        setModules(modules.map(module => {
            if (module.id === id) {
                if (field === 'file' && value instanceof File) {
                    const reader = new FileReader()
                    reader.onload = (e) => {
                        const fileContent = e.target?.result as string
                        setModules(prevModules => prevModules.map(m =>
                            m.id === id ? { ...m, fileContent, content: value.name } : m
                        ))
                    }
                    reader.readAsDataURL(value)
                    return { ...module, [field]: value, content: value.name }
                }
                return { ...module, [field]: value }
            }
            return module
        }))
    }

    const removeModule = (id: string) => {
        setModules(modules.filter(module => module.id !== id))
    }

    const generateContent = async () => {
        setIsGenerating(true);

        try {
            const formData = new FormData();

            formData.append('title', title);
            formData.append('lectureTopic', lectureTopic);
            formData.append('learningOutcomes', learningOutcomes);
            formData.append('description', description);

            referenceFiles.forEach((file) => {
                formData.append('referenceFiles', file);
            });

            const response = await fetch('http://localhost:8000/lecture/generate', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                throw new Error('Failed to generate lecture content.');
            }

            const data = await response.json();

            const parsedModules = data.content.map((module: any) => ({
                id: module.id,
                title: module.title || 'Untitled Module',
                content: module.content || '',
                type: module.type || 'text',
            }));

            setModules(parsedModules);

            if (data.effectivenessScore) {
                setEffectivenessScore(data.effectivenessScore);
            }

            toast.success("Lecture Generated")
        } catch (error) {
            console.error('Error generating content:', error);
            toast.error("Failed to Generate")
        } finally {
            setIsGenerating(false);
        }
    };

    const enhanceWithAI = async (id: string) => {
        setIsGenerating(true)
        try {
            const moduleToEnhance = modules.find(m => m.id === id)
            if (!moduleToEnhance) throw new Error('Module not found')

            const response = await fetch('http://localhost:8000/lecture/enhance', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    moduleId: id,
                    content: moduleToEnhance.content,
                    type: moduleToEnhance.type,
                }),
            })

            if (!response.ok) throw new Error('Failed to enhance content')

            const enhancedContent = await response.json()

            setModules(modules.map(module =>
                module.id === id ? { ...module, content: enhancedContent.content } : module
            ))


            toast.success("Module Enhanced")
        } catch (error) {
            console.error('Error enhancing content:', error)

            toast.error("Failed to enhance content")

        } finally {
            setIsGenerating(false)
        }
    }
    const router = useRouter()
    const saveContent = async (publish = false) => {
        try {
            const contentToSave = {
                title,
                lectureTopic: lectureTopic, // Ensure correct field mapping
                learningOutcomes,
                description,
                // context, // Ensure this field is included
                modules: modules.map((module) => ({
                    ...module,
                    file: undefined, // Remove non-serializable data
                    type: module.type, // Ensure valid type
                })),
            };

            const response = await fetch(`http://localhost:8000/lecture/${publish ? 'saveandpublish' : 'save'}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(contentToSave),
            });

            if (!response.ok) throw new Error('Failed to save content');

            // Success handling
            toast.success(publish ? 'Lecture Published' : 'Lecture Saved')
            router.push('/courses')

        } catch (error) {
            console.error('Error saving content:', error);
        }
    };


    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold tracking-tight">Content Generation</h2>
            <div className="flex space-x-4">
                <div className="flex-grow space-y-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Lecture Details</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="title">Lecture Title</Label>
                                    <Input
                                        id="title"
                                        value={title}
                                        onChange={(e) => setTitle(e.target.value)}
                                        placeholder="Enter lecture title"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="topic">Lecture Topic</Label>
                                    <Input
                                        id="topic"
                                        value={lectureTopic}
                                        onChange={(e) => setLectureTopic(e.target.value)}
                                        placeholder="Enter lecture topic"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="outcomes">Learning Outcomes</Label>
                                    <Textarea
                                        id="outcomes"
                                        value={learningOutcomes}
                                        onChange={(e) => setLearningOutcomes(e.target.value)}
                                        placeholder="Enter learning outcomes"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="description">Description</Label>
                                    <Textarea
                                        id="description"
                                        value={description}
                                        onChange={(e) => setDescription(e.target.value)}
                                        placeholder="Enter lecture description"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="references">Reference Files</Label>
                                    <Input
                                        id="references"
                                        type="file"
                                        multiple
                                        accept=".pdf,.docx"
                                        onChange={(e) => setReferenceFiles(Array.from(e.target.files || []))}
                                    />
                                </div>
                                <Button onClick={generateContent} disabled={isGenerating}>
                                    {isGenerating ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Generating...
                                        </>
                                    ) : (
                                        <>
                                            <Wand2 className="mr-2 h-4 w-4" />
                                            Generate Content
                                        </>
                                    )}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                    <Tabs defaultValue="edit">
                        <TabsList>
                            <TabsTrigger value="edit">Edit View</TabsTrigger>
                            <TabsTrigger value="final">Final View</TabsTrigger>
                        </TabsList>
                        <TabsContent value="edit">
                            <div className="space-y-4">
                                {modules.map((module, index) => (
                                    <Card
                                        key={module.id}
                                        draggable
                                        onDragStart={(e) => handleDragStart(e, module)}
                                        onDragOver={handleDragOver}
                                        onDrop={(e) => handleDrop(e, index)}
                                    >
                                        <CardHeader>
                                            <CardTitle>
                                                <Input
                                                    value={module.title}
                                                    onChange={(e) => updateModule(module.id, 'title', e.target.value)}
                                                />
                                            </CardTitle>
                                            <CardDescription>
                                                Type: {module.type.charAt(0).toUpperCase() + module.type.slice(1)}
                                            </CardDescription>
                                        </CardHeader>
                                        <CardContent>
                                            {module.type === 'text' && (
                                                <RichTextEditor
                                                    content={module.content}
                                                    onChange={(content) => updateModule(module.id, 'content', content)}
                                                />
                                            )}
                                            {module.type === 'video' && (
                                                <Input
                                                    value={module.content}
                                                    onChange={(e) => updateModule(module.id, 'content', e.target.value)}
                                                    placeholder="Enter video URL"
                                                />
                                            )}
                                            {module.type === 'quiz' && (
                                                <Textarea
                                                    value={module.content}
                                                    onChange={(e) => updateModule(module.id, 'content', e.target.value)}
                                                    placeholder="Enter quiz questions in JSON format"
                                                />
                                            )}
                                            {module.type === 'file' && (
                                                <div className="space-y-2">
                                                    <Input
                                                        type="file"
                                                        accept=".pdf,.docx"
                                                        onChange={(e) => {
                                                            const file = e.target.files?.[0]
                                                            if (file) {
                                                                updateModule(module.id, 'file', file)
                                                            }
                                                        }}
                                                    />
                                                    {module.content && (
                                                        <p className="text-sm text-muted-foreground">
                                                            File selected: {module.content}
                                                        </p>
                                                    )}
                                                </div>
                                            )}
                                        </CardContent>
                                        <CardFooter className="flex justify-between">
                                            <Button onClick={() => enhanceWithAI(module.id)} disabled={isGenerating}>
                                                {isGenerating ? 'Enhancing...' : 'Enhance with AI'}
                                            </Button>
                                            <Button variant="destructive" onClick={() => removeModule(module.id)}>
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </CardFooter>
                                    </Card>
                                ))}
                            </div>
                            <div className="mt-4 flex items-center justify-between">
                                <Popover>
                                    <PopoverTrigger asChild>
                                        <Button>
                                            <Plus className="mr-2 h-4 w-4" />
                                            Add Module
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-56">
                                        <div className="grid gap-4">
                                            <Button onClick={() => addModule('text')}>Add Text Module</Button>
                                            <Button onClick={() => addModule('video')}>Add Video Module</Button>
                                            <Button onClick={() => addModule('quiz')}>Add Quiz Module</Button>
                                            <Button onClick={() => addModule('file')}>Add File Module</Button>
                                        </div>
                                    </PopoverContent>
                                </Popover>
                                <div className='flex space-x-2'>
                                    <Button className='bg-secondary text-primary hover:text-secondary'>Cancel</Button>
                                    <Button onClick={() => saveContent()}>Save</Button>
                                    <Button onClick={() => saveContent(true)}>Save and Publish</Button>
                                </div>
                            </div>
                        </TabsContent>
                        <TabsContent value="final">
                            <div className="space-y-8">
                                <h3 className="text-2xl font-bold">{title}</h3>
                                {modules.map((module) => (
                                    <Card key={module.id}>
                                        <CardHeader>
                                            <CardTitle>{module.title}</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            {module.type === 'text' && (
                                                <div dangerouslySetInnerHTML={{ __html: module.content }} />
                                            )}
                                            {module.type === 'video' && (
                                                <div className="aspect-w-16 aspect-h-9">
                                                    <iframe src={module.content} allow="autoplay; encrypted-media" allowFullScreen />
                                                </div>
                                            )}
                                            {module.type === 'quiz' && (
                                                <div>
                                                    <h4 className="text-lg font-semibold mb-2">Quiz</h4>
                                                    <pre>{module.content}</pre>
                                                </div>
                                            )}
                                            {module.type === 'file' && (
                                                <div>
                                                    <h4 className="text-lg font-semibold mb-2">Attached File</h4>
                                                    {module.fileContent ? (
                                                        module.content.endsWith('.pdf') ? (
                                                            <embed
                                                                src={module.fileContent}
                                                                type="application/pdf"
                                                                width="100%"
                                                                height="600px"
                                                            />
                                                        ) : module.content.endsWith('.docx') ? (
                                                            <iframe
                                                                src={`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(module.fileContent)}`}
                                                                width="100%"
                                                                height="600px"
                                                                frameBorder="0"
                                                            >
                                                                This is an embedded <a target='_blank' href='http://office.com'>Microsoft Office</a> document, powered by <a target='_blank' href='http://office.com/webapps'>Office Online</a>.
                                                            </iframe>
                                                        ) : (
                                                            <p>Unsupported file type</p>
                                                        )
                                                    ) : (
                                                        <p>File content not available</p>
                                                    )}
                                                </div>
                                            )}
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        </TabsContent>
                    </Tabs>
                </div>
                <EffectivenessScore score={effectivenessScore} />
            </div>
        </div>
    )
}

