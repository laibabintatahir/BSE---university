import React, { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface QuizEditorProps {
    quizData: ModuleType['quizData']
    onChange: (newQuizData: ModuleType['quizData']) => void
}

export function QuizEditor({ quizData, onChange }: QuizEditorProps) {
    const [questions, setQuestions] = useState(quizData?.questions || [])

    const addQuestion = () => {
        const newQuestion = {
            id: Date.now().toString(),
            question: '',
            options: ['', '', '', ''],
            correctAnswer: 0
        }
        setQuestions([...questions, newQuestion])
        onChange({ questions: [...questions, newQuestion] })
    }

    const updateQuestion = (id: string, field: string, value: string | number) => {
        const updatedQuestions = questions.map(q =>
            q.id === id ? { ...q, [field]: value } : q
        )
        setQuestions(updatedQuestions)
        onChange({ questions: updatedQuestions })
    }

    return (
        <div className="space-y-4">
            {questions.map((q, index) => (
                <Card key={q.id}>
                    <CardHeader>
                        <CardTitle>Question {index + 1}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            <Label htmlFor={`question-${q.id}`}>Question</Label>
                            <Input
                                id={`question-${q.id}`}
                                value={q.question}
                                onChange={(e) => updateQuestion(q.id, 'question', e.target.value)}
                            />
                            {q.options.map((option, optionIndex) => (
                                <div key={optionIndex} className="flex items-center space-x-2">
                                    <Input
                                        value={option}
                                        onChange={(e) => {
                                            const newOptions = [...q.options]
                                            newOptions[optionIndex] = e.target.value
                                            updateQuestion(q.id, 'options', newOptions)
                                        }}
                                        placeholder={`Option ${optionIndex + 1}`}
                                    />
                                    <input
                                        type="radio"
                                        name={`correct-${q.id}`}
                                        checked={q.correctAnswer === optionIndex}
                                        onChange={() => updateQuestion(q.id, 'correctAnswer', optionIndex)}
                                    />
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            ))}
            <Button onClick={addQuestion}>Add Question</Button>
        </div>
    )
}
