import React from 'react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export type ModuleType = {
    id: string
    title: string
    content: string
    type: 'text' | 'video' | 'quiz'
}

interface ModuleListProps {
    modules: ModuleType[]
    updateModule: (id: string, field: keyof ModuleType, value: string) => void
    moveModule: (id: string, direction: 'up' | 'down') => void
}

export function ModuleList({ modules, updateModule, moveModule }: ModuleListProps) {
    return (
        <div className="space-y-4">
            {modules.map((module, index) => (
                <Card key={module.id}>
                    <CardHeader>
                        <CardTitle>
                            <Input
                                value={module.title}
                                onChange={(e) => updateModule(module.id, 'title', e.target.value)}
                            />
                        </CardTitle>
                        <CardDescription>
                            Type: {module.type.charAt(0).toUpperCase() + module.type.slice(1)}
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {module.type === 'text' && (
                            <Textarea
                                value={module.content}
                                onChange={(e) => updateModule(module.id, 'content', e.target.value)}
                                placeholder="Enter text content"
                                rows={5}
                            />
                        )}
                        {module.type === 'video' && (
                            <Input
                                value={module.content}
                                onChange={(e) => updateModule(module.id, 'content', e.target.value)}
                                placeholder="Enter video URL"
                            />
                        )}
                        {module.type === 'quiz' && (
                            <Textarea
                                value={module.content}
                                onChange={(e) => updateModule(module.id, 'content', e.target.value)}
                                placeholder="Enter quiz questions in JSON format"
                                rows={5}
                            />
                        )}
                    </CardContent>
                    <CardFooter className="justify-between">
                        <div>
                            <Button
                                onClick={() => moveModule(module.id, 'up')}
                                disabled={index === 0}
                                variant="outline"
                                size="sm"
                            >
                                Move Up
                            </Button>
                            <Button
                                onClick={() => moveModule(module.id, 'down')}
                                disabled={index === modules.length - 1}
                                variant="outline"
                                size="sm"
                                className="ml-2"
                            >
                                Move Down
                            </Button>
                        </div>
                        <Button>Enhance with AI</Button>
                    </CardFooter>
                </Card>
            ))}
        </div>
    )
}

