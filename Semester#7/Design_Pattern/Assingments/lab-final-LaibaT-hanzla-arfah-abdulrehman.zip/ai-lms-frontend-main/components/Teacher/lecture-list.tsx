import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Eye, Edit, Trash2, Send, Link } from 'lucide-react'
import { Badge } from "../ui/badge";

interface Lecture {
  id: string;
  title: string;
  status: 'saved' | 'published';
}

interface LectureListProps {
  lectures: Lecture[];
  onEdit?: (id: string) => void;
  onView: (id: string) => void;
  onDelete: (id: string) => void;
  onPublish?: (id: string) => void;
}

export function LectureList({ lectures, onEdit, onView, onDelete, onPublish }: LectureListProps) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Title</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {lectures.map((lecture) => (
          <TableRow key={lecture.id}>

            <TableCell>{lecture.title}</TableCell>
            <TableCell>
              <Badge className="bg-white hover:bg-white text-primary  uppercase">
                {lecture.status}
              </Badge>
            </TableCell>
            <TableCell>
              <div className="flex space-x-2">
                <Button variant="outline" size="icon" onClick={() => onView(lecture.id)}>
                  <Eye className="h-4 w-4" />
                </Button>
                {onEdit && lecture.status === 'saved' && (
                  <Button variant="outline" size="icon" onClick={() => onEdit(lecture.id)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                )}
                <Button variant="outline" size="icon" onClick={() => onDelete(lecture.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
                {onPublish && lecture.status === 'saved' && (
                  <Button variant="outline" size="icon" onClick={() => onPublish(lecture.id)}>
                    <Send className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

