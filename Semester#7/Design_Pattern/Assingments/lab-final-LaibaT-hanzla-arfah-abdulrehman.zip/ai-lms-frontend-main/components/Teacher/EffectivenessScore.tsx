import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface EffectivenessScoreProps {
    score: number
}

export function EffectivenessScore({ score }: EffectivenessScoreProps) {
    const clampedScore = Math.max(0, Math.min(100, score))
    const hue = (clampedScore * 120) / 100
    const color = `hsl(${hue}, 100%, 50%)`

    return (
        <Card className="w-64 h-fit sticky top-4">
            <CardHeader>
                <CardTitle>Effectiveness Score</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="flex flex-col items-center">
                    <div className="relative w-32 h-32">
                        <svg className="w-full h-full" viewBox="0 0 100 100">
                            <circle
                                className="text-muted-foreground stroke-current"
                                strokeWidth="10"
                                cx="50"
                                cy="50"
                                r="40"
                                fill="transparent"
                            />
                            <circle
                                stroke={color}
                                strokeWidth="10"
                                strokeLinecap="round"
                                cx="50"
                                cy="50"
                                r="40"
                                fill="transparent"
                                strokeDasharray={`${clampedScore * 2.51327}, 251.327`}
                                transform="rotate(-90 50 50)"
                            />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-2xl font-bold" style={{ color }}>
                                {clampedScore}%
                            </span>
                        </div>
                    </div>
                    <p className="mt-4 text-sm text-muted-foreground">Based on AI analysis</p>
                </div>
            </CardContent>
        </Card>
    )
}

