import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ModuleType } from '@/components/Teacher/ModuleList'
 
interface ModuleViewProps {
    modules: ModuleType[]
    title: string
}

function formatMarkdown(content: string): string {
    // This is a very basic markdown formatter
    // It handles only basic formatting like headers, bold, italic, and lists
    return content
        .replace(/^# (.*$)/gm, '<h1>$1</h1>')
        .replace(/^## (.*$)/gm, '<h2>$1</h2>')
        .replace(/^### (.*$)/gm, '<h3>$1</h3>')
        .replace(/\*\*(.*)\*\*/gm, '<strong>$1</strong>')
        .replace(/\*(.*)\*/gm, '<em>$1</em>')
        .replace(/^\s*[-+*]\s+(.*)/gm, '<li>$1</li>')
        .replace(/\n\n/g, '<br/>')
}

export function ModuleView({ modules, title }: ModuleViewProps) {
    return (
        <div className="space-y-8">
            <h3 className="text-2xl font-bold">{title}</h3>
            {modules.map((module) => (
                <Card key={module.id}>
                    <CardHeader>
                        <CardTitle>{module.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {module.type === 'text' && (
                            <div dangerouslySetInnerHTML={{ __html: formatMarkdown(module.content) }} />
                        )}
                        {module.type === 'video' && (
                            <div className="aspect-w-16 aspect-h-9">
                                <iframe src={module.content} allow="autoplay; encrypted-media" allowFullScreen />
                            </div>
                        )}
                        {module.type === 'quiz' && (
                            <div>
                                <h4 className="text-lg font-semibold mb-2">Quiz</h4>
                                <pre>{module.content}</pre>
                            </div>
                        )}
                    </CardContent>
                </Card>
            ))}
        </div>
    )
}

