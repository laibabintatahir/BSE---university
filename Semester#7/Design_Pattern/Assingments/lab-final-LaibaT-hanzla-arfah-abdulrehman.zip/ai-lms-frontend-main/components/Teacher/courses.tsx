'use client'
import { Book, FileText, Video } from 'lucide-react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

const courses = [
    {
        id: 1,
        title: 'Introduction to Computer Science',
        code: 'CS101',
        instructor: 'Dr. Jane Smith',
        progress: 75,
        materials: [
            { type: 'lecture', title: 'Lecture 1: Basics of Programming' },
            { type: 'reading', title: 'Chapter 1: Algorithms' },
            { type: 'video', title: 'Tutorial: Setting up your development environment' },
        ]
    },
    {
        id: 2,
        title: 'Advanced Mathematics',
        code: 'MATH301',
        instructor: 'Prof. John Doe',
        progress: 50,
        materials: [
            { type: 'lecture', title: 'Lecture 5: Linear Algebra' },
            { type: 'reading', title: 'Chapter 3: Matrices and Determinants' },
            { type: 'video', title: 'Problem Solving: Matrix Operations' },
        ]
    },
    {
        id: 3,
        title: 'Introduction to Psychology',
        code: 'PSYCH101',
        instructor: 'Dr. Emily Johnson',
        progress: 30,
        materials: [
            { type: 'lecture', title: 'Lecture 2: Cognitive Psychology' },
            { type: 'reading', title: 'Chapter 2: Memory and Learning' },
            { type: 'video', title: 'Case Study: Classical Conditioning' },
        ]
    },
]

export default function Courses() {
    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold tracking-tight">My Courses</h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {courses.map((course) => (
                    <Card key={course.id} className="flex flex-col">
                        <CardHeader>
                            <CardTitle>{course.title}</CardTitle>
                            <CardDescription>{course.code} - {course.instructor}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-1">
                            <Progress value={course.progress} className="mb-2" />
                            <p className="text-sm text-muted-foreground mb-4">{course.progress}% complete</p>
                            <h3 className="font-semibold mb-2">Recent Materials:</h3>
                            <ul className="space-y-2">
                                {course.materials.map((material, index) => (
                                    <li key={index} className="flex items-center text-sm">
                                        {material.type === 'lecture' && <Book className="w-4 h-4 mr-2 text-blue-500" />}
                                        {material.type === 'reading' && <FileText className="w-4 h-4 mr-2 text-green-500" />}
                                        {material.type === 'video' && <Video className="w-4 h-4 mr-2 text-red-500" />}
                                        <span>{material.title}</span>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                        <CardFooter>
                            <Button className="w-full"
                                onClick={() => window.location.href = `/courses/${course.id}`}
                            >Go to Course</Button>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </div>
    )
}