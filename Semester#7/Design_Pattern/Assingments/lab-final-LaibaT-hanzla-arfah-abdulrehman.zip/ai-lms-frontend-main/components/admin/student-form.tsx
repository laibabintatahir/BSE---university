'use client'

import * as React from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ConfirmationDialog } from "@/components/common/confirmation-dialog"
import toast from "react-hot-toast"
const formSchema = z.object({
    firstName: z.string().min(2, { message: "First name must be at least 2 characters." }),
    lastName: z.string().min(2, { message: "Last name must be at least 2 characters." }),
    dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, { message: "Invalid date format. Use YYYY-MM-DD." }),
    gender: z.enum(["male", "female", "other"]),
    enrollmentGrade: z.enum(["SSC-1", "SSC-2", "HSSC-1", "HSSC-2"]),
    major: z.enum(["Computer Science", "Biology", "Pre-Engineering", "Pre-Medical"]).optional(),
    contactNumber: z.string().regex(/^(\+92|0)?[0-9]{10}$/, { message: "Invalid Pakistani phone number." }),
    email: z.string().email({ message: "Invalid email address." }),
    address: z.string().min(5, { message: "Address must be at least 5 characters." }),
    guardianName: z.string().min(2, { message: "Guardian name must be at least 2 characters." }),
    guardianContact: z.string().regex(/^(\+92|0)?[0-9]{10}$/, { message: "Invalid Pakistani phone number." }),
})

type StudentFormProps = {
    initialData?: z.infer<typeof formSchema>
    onSubmit: (data: z.infer<typeof formSchema>) => void
    isEditing?: boolean
}

export function StudentForm({ initialData, onSubmit, isEditing = false }: StudentFormProps) {

    const [isConfirmDialogOpen, setIsConfirmDialogOpen] = React.useState(false)

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: initialData || {
            firstName: "",
            lastName: "",
            dateOfBirth: "",
            gender: "male",
            enrollmentGrade: "SSC-1",
            major: undefined,
            contactNumber: "",
            email: "",
            address: "",
            guardianName: "",
            guardianContact: "",
        },
    })

    const handleSubmit = (values: z.infer<typeof formSchema>) => {
        setIsConfirmDialogOpen(true)
    }

    const confirmSubmit = () => {
        setIsConfirmDialogOpen(false)
        onSubmit(form.getValues())
        if (isEditing) {
            toast.success(`${form.getValues().firstName} ${form.getValues().lastName} has been updated successfully.`)
        } else {
            toast.success(`${form.getValues().firstName} ${form.getValues().lastName} has been added successfully.`)
        }


    }

    return (
        <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-8">
                <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                                <Input placeholder="John" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                                <Input placeholder="Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="dateOfBirth"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Date of Birth</FormLabel>
                            <FormControl>
                                <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Gender</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select gender" />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="male">Male</SelectItem>
                                    <SelectItem value="female">Female</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="enrollmentGrade"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Enrollment Grade</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select enrollment grade" />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="SSC-1">SSC-1</SelectItem>
                                    <SelectItem value="SSC-2">SSC-2</SelectItem>
                                    <SelectItem value="HSSC-1">HSSC-1</SelectItem>
                                    <SelectItem value="HSSC-2">HSSC-2</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="major"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Major</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select major" />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    <SelectItem value="Computer Science">Computer Science</SelectItem>
                                    <SelectItem value="Biology">Biology</SelectItem>
                                    <SelectItem value="Pre-Engineering">Pre-Engineering</SelectItem>
                                    <SelectItem value="Pre-Medical">Pre-Medical</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormDescription>
                                Only applicable for HSSC-1 and HSSC-2 students.
                            </FormDescription>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="contactNumber"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Contact Number</FormLabel>
                            <FormControl>
                                <Input placeholder="+923001234567" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                                <Input type="email" placeholder="john.doe@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                                <Input placeholder="123 Main St, City, Country" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="guardianName"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Guardian Name</FormLabel>
                            <FormControl>
                                <Input placeholder="Jane Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="guardianContact"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Guardian Contact</FormLabel>
                            <FormControl>
                                <Input placeholder="+923009876543" {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <Button type="submit">{isEditing ? "Update Student" : "Create Student"}</Button>
            </form>
            <ConfirmationDialog
                isOpen={isConfirmDialogOpen}
                onClose={() => setIsConfirmDialogOpen(false)}
                onConfirm={confirmSubmit}
                title={isEditing ? "Update Student" : "Create Student"}
                description={`Are you sure you want to ${isEditing ? 'update' : 'create'} this student?`}
                confirmText={isEditing ? "Update" : "Create"}
            />
        </Form>
    )
}

