'use client'

import * as React from "react"
import { useDropzone } from 'react-dropzone'
import * as XLSX from 'xlsx'
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Checkbox } from "@/components/ui/checkbox"
import toast from "react-hot-toast"

interface TeacherData {
    firstName: string
    lastName: string
    dateOfBirth: string
    gender: string
    qualification: string
    specialization: string
    yearsOfExperience: number
    contactNumber: string
    email: string
    address: string
    employmentStatus: string
    joiningDate: string
}

export function BatchTeacherUpload() {
    const [teachers, setTeachers] = React.useState<TeacherData[]>([])
    const [selectedTeachers, setSelectedTeachers] = React.useState<Set<number>>(new Set())

    const onDrop = React.useCallback((acceptedFiles: File[]) => {
        const file = acceptedFiles[0]
        const reader = new FileReader()

        reader.onload = (e: ProgressEvent<FileReader>) => {
            const data = new Uint8Array(e.target?.result as ArrayBuffer)
            const workbook = XLSX.read(data, { type: 'array' })
            const sheetName = workbook.SheetNames[0]
            const worksheet = workbook.Sheets[sheetName]
            const jsonData = XLSX.utils.sheet_to_json(worksheet) as TeacherData[]
            setTeachers(jsonData)
            setSelectedTeachers(new Set(jsonData.map((_, index) => index)))
        }

        reader.readAsArrayBuffer(file)
    }, [])

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop, accept: {
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
            'application/vnd.ms-excel': ['.xls']
        }
    })

    const toggleTeacher = (index: number) => {
        const newSelected = new Set(selectedTeachers)
        if (newSelected.has(index)) {
            newSelected.delete(index)
        } else {
            newSelected.add(index)
        }
        setSelectedTeachers(newSelected)
    }

    const handleSubmit = () => {
        const selectedTeacherData = teachers.filter((_, index) => selectedTeachers.has(index))
        // Here you would typically send the selectedTeacherData to your API
        console.log(selectedTeacherData)
        toast.success(`Added ${selectedTeacherData.length} teachers`)
    }

    return (
        <div className="space-y-4">
            <div {...getRootProps()} className="border-2 border-dashed border-gray-300 p-6 text-center cursor-pointer">
                <input {...getInputProps()} />
                {isDragActive ? (
                    <p>Drop the Excel file here ...</p>
                ) : (
                    <p>Drag and drop an Excel file here, or click to select a file</p>
                )}
            </div>
            {teachers.length > 0 && (
                <>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[50px]">Select</TableHead>
                                <TableHead>First Name</TableHead>
                                <TableHead>Last Name</TableHead>
                                <TableHead>Specialization</TableHead>
                                <TableHead>Email</TableHead>
                                <TableHead>Employment Status</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {teachers.map((teacher, index) => (
                                <TableRow key={index}>
                                    <TableCell>
                                        <Checkbox
                                            checked={selectedTeachers.has(index)}
                                            onCheckedChange={() => toggleTeacher(index)}
                                        />
                                    </TableCell>
                                    <TableCell>{teacher.firstName}</TableCell>
                                    <TableCell>{teacher.lastName}</TableCell>
                                    <TableCell>{teacher.specialization}</TableCell>
                                    <TableCell>{teacher.email}</TableCell>
                                    <TableCell>{teacher.employmentStatus}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <Button onClick={handleSubmit}>Add Selected Teachers</Button>
                </>
            )}
        </div>
    )
}

