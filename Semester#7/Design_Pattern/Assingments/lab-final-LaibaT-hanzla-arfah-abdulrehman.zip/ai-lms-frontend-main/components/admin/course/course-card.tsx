import Link from 'next/link'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface CourseCardProps {
    id: string
    name: string
    description: string
    teacherName?: string
}

export function CourseCard({ id, name, description, teacherName }: CourseCardProps) {
    return (
        <Card className="w-full">
            <CardHeader>
                <CardTitle>{name}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                {teacherName && <p className="text-sm text-muted-foreground">Teacher: {teacherName}</p>}
            </CardContent>
            <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                    <Link href={`/courses/${id}`}>View Details</Link>
                </Button>
                <Button variant="outline" asChild>
                    <Link href={`/courses/edit/${id}`}>Edit</Link>
                </Button>
            </CardFooter>
        </Card>
    )
}

