'use client'

import * as React from "react"
import { useDropzone } from 'react-dropzone'
import * as XLSX from 'xlsx'
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Checkbox } from "@/components/ui/checkbox"
import toast from "react-hot-toast"
interface StudentData {
    firstName: string
    lastName: string
    dateOfBirth: string
    gender: string
    enrollmentGrade: string
    major?: string
    contactNumber: string
    email: string
    address: string
    guardianName: string
    guardianContact: string
}

export function BatchStudentUpload() {
    const [students, setStudents] = React.useState<StudentData[]>([])
    const [selectedStudents, setSelectedStudents] = React.useState<Set<number>>(new Set())

    const onDrop = React.useCallback((acceptedFiles: File[]) => {
        const file = acceptedFiles[0]
        const reader = new FileReader()

        reader.onload = (e: ProgressEvent<FileReader>) => {
            const data = new Uint8Array(e.target?.result as ArrayBuffer)
            const workbook = XLSX.read(data, { type: 'array' })
            const sheetName = workbook.SheetNames[0]
            const worksheet = workbook.Sheets[sheetName]
            const jsonData = XLSX.utils.sheet_to_json(worksheet) as StudentData[]
            setStudents(jsonData)
            setSelectedStudents(new Set(jsonData.map((_, index) => index)))
        }

        reader.readAsArrayBuffer(file)
    }, [])

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop, accept: {
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
            'application/vnd.ms-excel': ['.xls']
        }
    })

    const toggleStudent = (index: number) => {
        const newSelected = new Set(selectedStudents)
        if (newSelected.has(index)) {
            newSelected.delete(index)
        } else {
            newSelected.add(index)
        }
        setSelectedStudents(newSelected)
    }

    const handleSubmit = () => {
        const selectedStudentData = students.filter((_, index) => selectedStudents.has(index))
        // Here you would typically send the selectedStudentData to your API
        console.log(selectedStudentData)
        toast.success(`Added ${selectedStudentData.length} students`)
    }

    return (
        <div className="space-y-4">
            <div {...getRootProps()} className="border-2 border-dashed border-gray-300 p-6 text-center cursor-pointer">
                <input {...getInputProps()} />
                {isDragActive ? (
                    <p>Drop the Excel file here ...</p>
                ) : (
                    <p>Drag and drop an Excel file here, or click to select a file</p>
                )}
            </div>
            {students.length > 0 && (
                <>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[50px]">Select</TableHead>
                                <TableHead>First Name</TableHead>
                                <TableHead>Last Name</TableHead>
                                <TableHead>Enrollment Grade</TableHead>
                                <TableHead>Major</TableHead>
                                <TableHead>Email</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {students.map((student, index) => (
                                <TableRow key={index}>
                                    <TableCell>
                                        <Checkbox
                                            checked={selectedStudents.has(index)}
                                            onCheckedChange={() => toggleStudent(index)}
                                        />
                                    </TableCell>
                                    <TableCell>{student.firstName}</TableCell>
                                    <TableCell>{student.lastName}</TableCell>
                                    <TableCell>{student.enrollmentGrade}</TableCell>
                                    <TableCell>{student.major || 'N/A'}</TableCell>
                                    <TableCell>{student.email}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <Button onClick={handleSubmit}>Add Selected Students</Button>
                </>
            )}
        </div>
    )
}

