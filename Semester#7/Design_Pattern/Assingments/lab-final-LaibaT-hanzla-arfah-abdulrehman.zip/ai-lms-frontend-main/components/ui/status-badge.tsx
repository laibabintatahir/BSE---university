import { cn } from "@/lib/utils"

interface StatusBadgeProps {
  status: Status
  className?: string
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const getStatusColor = (status: Status) => {
    switch (status) {
      case 'ungraded':
        return 'bg-yellow-100 text-yellow-800'
      case 'ai-graded':
        return 'bg-blue-100 text-blue-800'
      case 'graded':
        return 'bg-green-100 text-green-800'
      case 'due':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <span className={cn(
      "px-2 py-1 rounded-full text-xs font-medium",
      getStatusColor(status),
      className
    )}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  )
}

