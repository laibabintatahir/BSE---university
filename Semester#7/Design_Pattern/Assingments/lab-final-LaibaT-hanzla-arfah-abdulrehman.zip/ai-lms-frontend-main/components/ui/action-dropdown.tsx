"use client"

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MoreVertical } from 'lucide-react'
import { Button } from "@/components/ui/button"

interface ActionDropdownProps {
  onAction: (action: ActionType) => void
}

export function ActionDropdown({ onAction }: ActionDropdownProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon">
          <MoreVertical className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => onAction('auto')}>
          Auto Grade
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => onAction('disable')}>
          Disable
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => onAction('make')}>
          Make
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

