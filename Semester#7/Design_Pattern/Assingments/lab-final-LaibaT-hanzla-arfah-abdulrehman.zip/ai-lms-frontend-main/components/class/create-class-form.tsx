'use client'

import * as React from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { TeacherSelect } from "@/components/class/teacher-select"
import { StudentDialog } from "@/components/class/student-dialog"
import { SubjectTeacherDialog } from "@/components/class/subject-teacher-dialog"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const formSchema = z.object({
    name: z.string().min(2, { message: "Class name must be at least 2 characters." }),
    section: z.string().min(1, { message: "Section is required." }),
    session: z.string().min(4, { message: "Session is required (e.g., 2023)." }),
    inchargeId: z.string().min(1, { message: "Class teacher is required." }),
    description: z.string().optional(),
})

export function CreateClassForm({ initialData }: { initialData?: any }) {
    const [students, setStudents] = React.useState<string[]>(initialData?.students || [])
    const [subjectTeachers, setSubjectTeachers] = React.useState<Array<{ subjectId: string, teacherId: string }>>(initialData?.subjectTeachers || [])

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: initialData || {
            name: "",
            section: "",
            session: new Date().getFullYear().toString(),
            inchargeId: "",
            description: "",
        },
    })

    function onSubmit(values: z.infer<typeof formSchema>) {
        console.log({ ...values, students, subjectTeachers })
        // Here you would typically send the data to your API
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>{initialData ? "Edit Class" : "Create New Class"}</CardTitle>
            </CardHeader>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <CardContent className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Class Name</FormLabel>
                                        <FormControl>
                                            <Input placeholder="e.g. 9th, 10th, 11th" {...field} />
                                        </FormControl>
                                        <FormDescription>The name or number of the class.</FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="section"
                                render={({ field }) => (
                                    <FormItem><FormLabel>Section</FormLabel>
                                        <FormControl>
                                            <Input placeholder="e.g. A, B, Rose, Tulip" {...field} />
                                        </FormControl>
                                        <FormDescription>The section of the class.</FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                                control={form.control}
                                name="session"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Session</FormLabel>
                                        <FormControl>
                                            <Input placeholder="e.g. 2023" {...field} />
                                        </FormControl>
                                        <FormDescription>The academic year for this class.</FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="inchargeId"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Class Teacher</FormLabel>
                                        <FormControl>
                                            <TeacherSelect onSelect={field.onChange} />
                                        </FormControl>
                                        <FormDescription>Select the teacher in charge of this class.</FormDescription>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Description (Optional)</FormLabel>
                                    <FormControl>
                                        <Textarea placeholder="Add any additional information about the class" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <div className="flex space-x-4">
                            <StudentDialog students={students} setStudents={setStudents} />
                            <SubjectTeacherDialog subjectTeachers={subjectTeachers} setSubjectTeachers={setSubjectTeachers} />
                        </div>
                    </CardContent>
                    <CardFooter>
                        <Button type="submit">{initialData ? "Update Class" : "Create Class"}</Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    )
}

