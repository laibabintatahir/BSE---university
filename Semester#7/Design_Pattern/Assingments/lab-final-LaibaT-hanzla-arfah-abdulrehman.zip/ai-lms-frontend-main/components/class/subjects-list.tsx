import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { PlusCircle, Edit, Trash2 } from 'lucide-react'

interface Subject {
    id: string
    name: string
    teacher: string
}

interface SubjectsListProps {
    subjects: Subject[]
}

export function SubjectsList({ subjects }: SubjectsListProps) {
    return (
        <Card>
            <CardHeader>
                <CardTitle>Subjects</CardTitle>
                <Button>
                    <PlusCircle className="mr-2 h-4 w-4" /> Add Subject
                </Button>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Subject Name</TableHead>
                            <TableHead>Teacher</TableHead>
                            <TableHead>Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {subjects.map((subject) => (
                            <TableRow key={subject.id}>
                                <TableCell>{subject.name}</TableCell>
                                <TableCell>{subject.teacher}</TableCell>
                                <TableCell>
                                    <Button variant="ghost" size="sm">
                                        <Edit className="h-4 w-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm">
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    )
}

