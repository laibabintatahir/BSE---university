import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Edit } from "lucide-react"

interface TimetableProps {
    timetable: {
        [day: string]: { time: string; subject: string }[]
    }
}

export function Timetable({ timetable }: TimetableProps) {
    const days = Object.keys(timetable)
    const maxPeriods = Math.max(...days.map(day => timetable[day].length))

    return (
        <Card>
            <CardHeader>
                <CardTitle>Timetable</CardTitle>
                <Button>
                    <Edit className="mr-2 h-4 w-4" /> Edit Timetable
                </Button>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Time</TableHead>
                            {days.map(day => (
                                <TableHead key={day}>{day}</TableHead>
                            ))}
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {Array.from({ length: maxPeriods }).map((_, index) => (
                            <TableRow key={index}>
                                <TableCell>{timetable[days[0]][index]?.time || ''}</TableCell>
                                {days.map(day => (
                                    <TableCell key={day}>
                                        {timetable[day][index]?.subject || ''}
                                    </TableCell>
                                ))}
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    )
}

