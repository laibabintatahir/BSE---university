'use client'

import * as React from "react"
import { Button } from "@/components/ui/button"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"

export function SubjectDialog({ subjects, setSubjects }: { subjects: string[], setSubjects: React.Dispatch<React.SetStateAction<string[]>> }) {
    const [newSubject, setNewSubject] = React.useState("")

    const handleAddSubject = () => {
        if (newSubject.trim() !== "") {
            setSubjects((prev) => [...prev, newSubject.trim()])
            setNewSubject("")
        }
    }

    const handleRemoveSubject = (subject: string) => {
        setSubjects((prev) => prev.filter((s) => s !== subject))
    }

    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button variant="outline">Manage Subjects</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Manage Subjects</DialogTitle>
                    <DialogDescription>
                        Add or remove subjects for this class.
                    </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <div className="flex items-center gap-4">
                        <Input
                            id="subject"
                            value={newSubject}
                            onChange={(e) => setNewSubject(e.target.value)}
                            placeholder="Enter subject name"
                        />
                        <Button onClick={handleAddSubject}>Add</Button>
                    </div>
                    <ScrollArea className="h-[200px] w-full rounded-md border p-4">
                        {subjects.map((subject, index) => (
                            <div key={index} className="flex items-center justify-between mb-2">
                                <span>{subject}</span>
                                <Button variant="ghost" onClick={() => handleRemoveSubject(subject)}>Remove</Button>
                            </div>
                        ))}
                    </ScrollArea>
                </div>
            </DialogContent>
        </Dialog>
    )
}

