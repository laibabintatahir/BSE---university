import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Edit, Users, BookOpen, Calendar } from 'lucide-react'

interface ClassDetailsProps {
    classData: {
        id: string
        name: string
        section: string
        incharge: string
        studentsCount: number
        subjectsCount: number
    }
}

export function ClassDetails({ classData }: ClassDetailsProps) {
    return (
        <Card>
            <CardHeader>
                <CardTitle>{classData.name} - Section {classData.section}</CardTitle>
                <CardDescription>Class Incharge: {classData.incharge}</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center">
                        <Users className="mr-2" />
                        <span>{classData.studentsCount} Students</span>
                    </div>
                    <div className="flex items-center">
                        <BookOpen className="mr-2" />
                        <span>{classData.subjectsCount} Subjects</span>
                    </div>
                </div>
                <Button className="mt-4" variant="outline">
                    <Edit className="mr-2 h-4 w-4" /> Edit Class Details
                </Button>
            </CardContent>
        </Card>
    )
}

