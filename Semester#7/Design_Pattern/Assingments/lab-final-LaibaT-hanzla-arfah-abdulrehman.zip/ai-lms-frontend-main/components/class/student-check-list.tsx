'use client'

import * as React from "react"
import { Checkbox } from "@/components/ui/checkbox"

interface Student {
    id: string
    name: string
}

const students: Student[] = [
    { id: "1", name: "Alice Johnson" },
    { id: "2", name: "Bob Smith" },
    { id: "3", name: "Charlie Brown" },
    { id: "4", name: "Diana Prince" },
    { id: "5", name: "Ethan Hunt" },
]

export function StudentCheckList({ onSelect }: { onSelect: (selectedIds: string[]) => void }) {
    const [selectedStudents, setSelectedStudents] = React.useState<string[]>([])

    const handleStudentToggle = (studentId: string) => {
        setSelectedStudents((prev) =>
            prev.includes(studentId)
                ? prev.filter((id) => id !== studentId)
                : [...prev, studentId]
        )
    }

    React.useEffect(() => {
        onSelect(selectedStudents)
    }, [selectedStudents, onSelect])

    return (
        <div className="space-y-2">
            {students.map((student) => (
                <div key={student.id} className="flex items-center space-x-2">
                    <Checkbox
                        id={`student-${student.id}`}
                        checked={selectedStudents.includes(student.id)}
                        onCheckedChange={() => handleStudentToggle(student.id)}
                    />
                    <label
                        htmlFor={`student-${student.id}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                        {student.name}
                    </label>
                </div>
            ))}
        </div>
    )
}

