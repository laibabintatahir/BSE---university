'use client'

import * as React from "react"
import { Button } from "@/components/ui/button"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"

// Simulated API data
const allStudents = [
    { id: "1", name: "Alice Johnson" },
    { id: "2", name: "Bob Smith" },
    { id: "3", name: "Charlie Brown" },
    { id: "4", name: "Diana Prince" },
    { id: "5", name: "Ethan Hunt" },
]

export function StudentDialog({ students, setStudents }: { students: string[], setStudents: React.Dispatch<React.SetStateAction<string[]>> }) {
    const [selectedStudents, setSelectedStudents] = React.useState<string[]>(students)

    const handleStudentToggle = (studentId: string) => {
        setSelectedStudents((prev) =>
            prev.includes(studentId)
                ? prev.filter((id) => id !== studentId)
                : [...prev, studentId]
        )
    }

    const handleSave = () => {
        setStudents(selectedStudents)
    }

    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button variant="outline">Manage Students</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Manage Students</DialogTitle>
                    <DialogDescription>
                        Select the students to enroll in this class.
                    </DialogDescription>
                </DialogHeader>
                <ScrollArea className="h-[300px] w-full rounded-md border p-4">
                    {allStudents.map((student) => (
                        <div key={student.id} className="flex items-center space-x-2 mb-2">
                            <Checkbox
                                id={`student-${student.id}`}
                                checked={selectedStudents.includes(student.id)}
                                onCheckedChange={() => handleStudentToggle(student.id)}
                            />
                            <label
                                htmlFor={`student-${student.id}`}
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                                {student.name}
                            </label>
                        </div>
                    ))}
                </ScrollArea>
                <Button onClick={handleSave}>Save</Button>
            </DialogContent>
        </Dialog>
    )
}

