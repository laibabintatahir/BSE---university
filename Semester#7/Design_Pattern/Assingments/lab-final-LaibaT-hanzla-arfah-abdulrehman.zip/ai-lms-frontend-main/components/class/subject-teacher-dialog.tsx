'use client'

import * as React from "react"
import { Button } from "@/components/ui/button"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { TeacherSelect } from "@/components/class/teacher-select"

// Simulated API data
const subjects = [
    { id: "1", name: "Mathematics" },
    { id: "2", name: "Physics" },
    { id: "3", name: "Chemistry" },
    { id: "4", name: "Biology" },
    { id: "5", name: "English" },
]

interface SubjectTeacherDialogProps {
    subjectTeachers: Array<{ subjectId: string; teacherId: string }>
    setSubjectTeachers: React.Dispatch<React.SetStateAction<Array<{ subjectId: string; teacherId: string }>>>
}

export function SubjectTeacherDialog({ subjectTeachers, setSubjectTeachers }: SubjectTeacherDialogProps) {
    const [open, setOpen] = React.useState(false)

    const handleTeacherSelect = (subjectId: string, teacherId: string) => {
        setSubjectTeachers((prev) => {
            const index = prev.findIndex((st) => st.subjectId === subjectId)
            if (index !== -1) {
                return [...prev.slice(0, index), { subjectId, teacherId }, ...prev.slice(index + 1)]
            } else {
                return [...prev, { subjectId, teacherId }]
            }
        })
    }

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button variant="outline">Assign Subject Teachers</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Assign Subject Teachers</DialogTitle>
                    <DialogDescription>
                        Select teachers for each subject in this class.
                    </DialogDescription>
                </DialogHeader>
                <ScrollArea className="h-[300px] w-full rounded-md border p-4">
                    {subjects.map((subject) => (
                        <div key={subject.id} className="mb-4">
                            <Label htmlFor={`subject-${subject.id}`} className="text-right">
                                {subject.name}
                            </Label>
                            <TeacherSelect
                                onSelect={(teacherId) => handleTeacherSelect(subject.id, teacherId)}
                                value={subjectTeachers.find((st) => st.subjectId === subject.id)?.teacherId}
                            />
                        </div>
                    ))}
                </ScrollArea>
                <Button onClick={() => setOpen(false)}>Done</Button>
            </DialogContent>
        </Dialog>
    )
}

