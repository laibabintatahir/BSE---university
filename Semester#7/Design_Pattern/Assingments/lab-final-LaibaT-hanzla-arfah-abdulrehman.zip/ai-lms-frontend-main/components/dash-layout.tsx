"use client"
import React, { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { Bell, BookOpen, Calendar, FileText, GraduationCap, Home, LayoutDashboard, LogOut, MessageSquare, Settings, User, HelpCircle, Book, Brain, Activity, Menu, MenuIcon, ShieldCloseIcon, CrossIcon, PanelLeftCloseIcon, LogOutIcon, User2, PenBoxIcon } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import { DropdownMenu, DropdownMenuTrigger } from '@radix-ui/react-dropdown-menu'
import { DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator } from './ui/dropdown-menu'
import { signOut, useSession } from 'next-auth/react'

const sidebarItems = [
    { icon: LayoutDashboard, label: 'Dashboard', href: '/' },
    { icon: BookOpen, label: 'Courses', href: '/courses' },
    { icon: Calendar, label: 'Timetable', href: '/timetable' },
    { icon: FileText, label: 'Assignments', href: '/assignments' },
    { icon: FileText, label: 'Quiz', href: '/quizzes' },
    { icon: GraduationCap, label: 'Grades', href: '/grades' },
    { icon: Book, label: 'Library', href: '/library' },
    { icon: Brain, label: 'AI Assistant', href: '/ai-assistant' },
    { icon: HelpCircle, label: 'Support', href: '/support' },
]


const teacherSidebarItems = [
    { icon: LayoutDashboard, label: 'Dashboard', href: '/' },
    { icon: BookOpen, label: 'Courses', href: '/courses' },
    { icon: Calendar, label: 'Timetable', href: '/timetable' },
    { icon: FileText, label: 'Assignments', href: '/assignments' },
    { icon: FileText, label: 'Quiz', href: '/quizzes' },
    // { icon: GraduationCap, label: 'Grades', href: '/grades' },
    { icon: Book, label: 'Library', href: '/library' },
    { icon: Brain, label: 'AI Assistant', href: '/ai-assistant' },
    // { icon: Activity, label: 'Analytics', href: '/analytics' },
    { icon: HelpCircle, label: 'Support', href: '/support' },
]

const adminSidebarItems = [
    { icon: LayoutDashboard, label: 'Dashboard', href: '/' },
    { icon: PenBoxIcon, label: 'Classes', href: '/classes' },
    { icon: User2, label: 'Users', href: '/users' },
    { icon: FileText, label: 'Courses', href: '/course-catalog' },
    { icon: GraduationCap, label: 'Students', href: '/students' },
    { icon: BookOpen, label: 'Teachers', href: '/teachers' },
    { icon: ShieldCloseIcon, label: 'Admins', href: '/admins' },
    { icon: Settings, label: 'Settings', href: '/settings' },

]


interface DashLink {
    icon: React.ElementType
    label: string
    href: string
}


export default function Layout({ children, role }: { children: React.ReactNode, role: string }) {

    const [menuLinks, setMenuLinks] = useState<DashLink[]>([])
    const [sidebarOpen, setSidebarOpen] = useState(false)
    const pathname = usePathname()
    // const { data: session } = useSession()

    useEffect(() => {
        if (role === 'teacher') {
            setMenuLinks(teacherSidebarItems)
        } else if (role === 'student') {
            setMenuLinks(sidebarItems)
        } else {
            setMenuLinks(adminSidebarItems)
        }
    }, [])
    return (
        <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
            {/* Sidebar */}
            <aside className={`bg-white dark:bg-gray-800 w-64 min-h-screen flex flex-col transition-all duration-300 ease-in-out ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:static z-30`}>
                <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
                    <Link href="/" className="flex items-center space-x-2">
                        <GraduationCap className="h-8 w-8 text-primary" />
                        <span className="text-xl font-bold text-primary">ClassEdge</span>
                    </Link>
                    <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(false)} className="lg:hidden">
                        <PanelLeftCloseIcon className='h-6 w-6' />
                    </Button>
                </div>
                <nav className="flex-1 overflow-y-auto py-4">
                    <ul className="space-y-2 px-2">
                        {
                            menuLinks.map((item) => (
                                <li key={item.href}>
                                    <Link href={item.href} className={cn(
                                        "flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors",
                                        pathname === item.href
                                            ? "bg-primary text-primary-foreground"
                                            : "text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                                    )}>
                                        <item.icon className="h-5 w-5" />
                                        <span>{item.label}</span>
                                    </Link>
                                </li>
                            ))}
                    </ul>
                </nav>
                <div className="p-4 border-t dark:border-gray-700">
                    <Link href="/profile" className="flex items-center space-x-2 text-gray-700 dark:text-gray-200 hover:text-primary">
                        <User className="h-5 w-5" />
                        <span>Profile</span>
                    </Link>
                    <Link href="/settings" className="flex items-center space-x-2 mt-2 text-gray-700 dark:text-gray-200 hover:text-primary">
                        <Settings className="h-5 w-5" />
                        <span>Settings</span>
                    </Link>
                    <Button variant="ghost" className="w-full mt-4 text-red-600 hover:text-red-700 hover:bg-red-100">
                        <LogOut className="h-5 w-5 mr-2" />
                        Logout
                    </Button>
                </div>
            </aside>

            {/* Main content */}
            <div className="flex-1 flex flex-col overflow-hidden">
                {/* Top bar */}
                <header className="bg-white dark:bg-gray-800 shadow-sm z-20">
                    <div className=" mx-auto py-4 px-4 sm:px-6 lg:px-8 flex lg:justify-end justify-between items-center">
                        <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(true)} className="lg:hidden p-0 m-0 border-2">
                            <MenuIcon className="h-8 w-8" />
                        </Button>

                        <div className="flex items-center">
                            <Button variant="ghost" size="icon">
                                <Bell className="h-5 w-5" />
                            </Button>
                            <DropdownMenu>
                                <DropdownMenuTrigger>
                                    <Avatar className="ml-4 cursor-pointer">
                                        <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Student" />
                                        <AvatarFallback>
                                            {
                                                role === 'teacher' ? 'T' : 'S'
                                            }
                                        </AvatarFallback>
                                    </Avatar>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent className='w-64'>
                                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem>Profile</DropdownMenuItem>
                                    <DropdownMenuItem>Team</DropdownMenuItem>
                                    <DropdownMenuItem>Subscription</DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem
                                        onClick={() => signOut()}
                                    >
                                        <LogOutIcon className='h-6 w-6' />
                                        Logout</DropdownMenuItem>

                                </DropdownMenuContent>

                            </DropdownMenu>
                        </div>
                    </div>
                </header>

                {/* Page content */}
                <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900 md:p-8 p-4">
                    {children}
                </main>
            </div>
        </div>
    )
}