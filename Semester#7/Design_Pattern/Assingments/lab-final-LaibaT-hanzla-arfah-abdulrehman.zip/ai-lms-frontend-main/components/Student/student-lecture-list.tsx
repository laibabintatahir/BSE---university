import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Eye } from 'lucide-react'

interface Lecture {
    id: string;
    title: string;
    status: 'saved' | 'published';
}

interface StudentLectureListProps {
    lectures: Lecture[];
    onView: (id: string) => void;
}

export function StudentLectureList({ lectures, onView }: StudentLectureListProps) {
    return (
        <Table>
            <TableHeader>
                <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Actions</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {lectures.map((lecture) => (
                    <TableRow key={lecture.id}>
                        <TableCell>{lecture.title}</TableCell>
                        <TableCell>
                            <Button variant="outline" size="icon" onClick={() => onView(lecture.id)}>
                                <Eye className="h-4 w-4" />
                            </Button>
                        </TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    )
}

