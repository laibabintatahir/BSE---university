export type Status = 'ungraded' | 'ai-graded' | 'graded' | 'due'

export interface Assignment {
  id: string
  title: string
  course: string
  dueDate: string
  status: Status
  aiGrading: boolean
  rubrics: string[]
  content: string
  totalMarks: number
}

export interface Quiz {
  id: string
  title: string
  course: string
  dueDate: string
  status: Status
  aiGrading: boolean
  rubrics: string[]
  questionTypes: ('mcq' | 'fitb' | 'short')[]
  questions: Question[]
  totalMarks: number
}

export interface Question {
  id: string
  type: 'mcq' | 'fitb' | 'short'
  content: string
  marks: number
  options?: string[]
  correctAnswer?: string
}

export interface Submission {
  id: string
  studentName: string
  registrationNumber: string
  obtainedMarks: number
  status: 'ai-graded' | 'human-graded' | 'flagged'
  submissionDate: string
  file: string
}

