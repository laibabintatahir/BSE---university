import NextAuth from 'next-auth';
import Credentials from 'next-auth/providers/credentials';
import { DefaultSession, User } from 'next-auth';

declare module 'next-auth' {
  interface Session extends DefaultSession {
    user: {
      id: string;
      name: string;
      role: string;
      email: string;
    };
  }
}

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    Credentials({
      credentials: {
        email: {},
        regNo: {},
        userType: {},
        password: {},
      },
      authorize: async (credentials) => {
        let user = null;
        const dbUser = {
          email: 'john@email.com',
          regNo: 'ssc-24-015',
          password: '123',  
          role: 'student',
          emailVerified: null,
        };

        const dbusers = [
          { ...dbUser },
          {
            email: 'jane@email.com',
            password: '123',
            role: 'admin',
            emailVerified: null,
          },
          {
            email: 'jack@email.com',
            password: '123',
            role: 'teacher',
            emailVerified: null,
          },
        ];

        if (credentials.userType === 'teacher') {
          // find user in dbusers
          user = dbusers.find((u) => u.email === credentials.email);
        } else if (credentials.userType === 'student') {
          if (credentials.regNo === dbUser.regNo) {
            // find user in dbusers
            user = dbUser;
          }
        } else if (credentials.userType === 'admin') {
          // find user in dbusers
          user = dbusers.find((u) => u.email === credentials.email);
        } else {
          throw new Error('Invalid User Type.');
        }
        if (!user) {
          // logic to salt and hash password
          // No user found, so this is their first attempt to login
          // Optionally, this is also the place you could do a user registration
          throw new Error('Invalid credentials.');
        }

        // return user object with their profile data
        return user;
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }: { token: any; user?: any }) {
      if (user) {
        token.id = user.id;
        token.name = user.name;
        token.role = user.role;
      }
      return token;
    },
    async session({ session, token }: { session: any; token: any }) {
      if (token?.id) {
        session.user.id = token.id;
      }
      // add name to session
      session.user.name = token.name;
      session.user.role = token.role;
      return session;
    },
  },
  secret: process.env.NEXT_AUTH_SECRET,
});
  