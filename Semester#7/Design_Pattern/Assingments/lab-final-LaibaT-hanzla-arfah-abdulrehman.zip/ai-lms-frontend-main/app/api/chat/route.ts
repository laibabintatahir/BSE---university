import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const { message, lectureId } = await req.json();

  // Dummy response - in a real scenario, this would interact with an AI model
  const response = `This is a dummy response to your message: "${message}" for lecture ${lectureId}`;

  return NextResponse.json({ response });
}
