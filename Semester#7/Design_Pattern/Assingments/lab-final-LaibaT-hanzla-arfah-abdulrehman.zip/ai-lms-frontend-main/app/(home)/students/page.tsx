import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { StudentsTable, Student } from "@/components/admin/students-table"
import { auth } from '@/auth'

// This would typically come from your API or database
const dummyStudents: Student[] = [
    {
        id: "1",
        firstName: "John",
        lastName: "Doe",
        enrollmentGrade: "SSC-1",
        email: "john.doe@example.com",
    },
    {
        id: "2",
        firstName: "Jane",
        lastName: "Smith",
        enrollmentGrade: "HSSC-2",
        major: "Pre-Medical",
        email: "jane.smith@example.com",
    },
    // Add more dummy data as needed
]

export default async function StudentsPage() {

    const session = await auth()

    if (!session || !session.user.role.includes('admin')) {
        return <div>Access Denied</div>
    }
    return (
        <div className="container mx-auto ">
            <h1 className="text-2xl font-bold mb-5">Students</h1>
            <div className="mb-4 flex gap-4">
                <Link href="/students/create">
                    <Button>Add Student</Button>
                </Link>
                <Link href="/students/batch-create">
                    <Button variant="outline" className='border-primary'>Batch Add Students</Button>
                </Link>
            </div>
            <StudentsTable data={dummyStudents} />
        </div>
    )
}

