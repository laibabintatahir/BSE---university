'use client'
import { StudentForm } from "@/components/admin/student-form"
import { Card, CardContent } from "@/components/ui/card";

// This would typically come from your API or database
const dummyStudent: {
    id: string;
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    gender: "male" | "female" | "other";
    enrollmentGrade: "SSC-1" | "SSC-2" | "HSSC-1" | "HSSC-2";
    contactNumber: string;
    email: string;
    address: string;
    guardianName: string;
    guardianContact: string;
} = {
    id: "1",
    firstName: "John",
    lastName: "Doe",
    dateOfBirth: "2005-05-15",
    gender: "male",
    enrollmentGrade: "SSC-1",
    contactNumber: "+923001234567",
    email: "john.doe@example.com",
    address: "123 Main St, Karachi, Pakistan",
    guardianName: "Jane Doe",
    guardianContact: "+923009876543",
}

export default function EditStudentPage({ params }: { params: { studentId: string } }) {
    const handleSubmit = (data: any) => {
        // Here you would typically send the data to your API
        console.log(data)
    }

    return (
        <div className="container mx-auto ">
            <Card>
                <CardContent className="p-4 px-6 m-0">
                    <h1 className="text-2xl font-bold mb-5">Edit Student</h1>
                    <StudentForm initialData={dummyStudent} onSubmit={handleSubmit} isEditing />
                </CardContent>
            </Card>
        </div>
    )
}

