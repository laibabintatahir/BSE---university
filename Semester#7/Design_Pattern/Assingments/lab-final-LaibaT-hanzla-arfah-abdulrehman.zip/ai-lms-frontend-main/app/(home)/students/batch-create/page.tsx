import { BatchStudentUpload } from "@/components/admin/batch-student-upload"

export default function BatchCreateStudentsPage() {
    return (
        <div className="container mx-auto py-10">
            <h1 className="text-2xl font-bold mb-5">Batch Create Students</h1>
            <BatchStudentUpload />
        </div>
    )
}

