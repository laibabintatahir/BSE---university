"use client"

import { useState } from 'react'
import { User, Mail, Phone, Book, Bell } from 'lucide-react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Profile() {
    const [profile, setProfile] = useState({
        name: 'John Doe',
        email: 'john.doe@example.com',
        phone: '+1 234 567 8900',
        major: 'Computer Science',
        notifications: {
            email: true,
            sms: false,
        }
    })

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target
        setProfile(prev => ({ ...prev, [name]: value }))
    }

    const handleNotificationChange = (type: string) => {
        setProfile(prev => ({
            ...prev,
            notifications: {
                ...prev.notifications,
                [type as keyof typeof prev.notifications]: !prev.notifications[type as keyof typeof prev.notifications]
            }
        }))
    }

    const handleSave = () => {
        // TODO: Implement save functionality
        console.log('Saving profile:', profile)
    }

    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold tracking-tight">My Profile</h2>
            <div className="grid gap-4 md:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle>Personal Information</CardTitle>
                        <CardDescription>Update your personal details</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center space-x-4">
                            <Avatar className="h-20 w-20">
                                <AvatarImage src="/placeholder.svg?height=80&width=80" alt={profile.name} />
                                <AvatarFallback>{profile.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <Button>Change Avatar</Button>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="name">Full Name</Label>
                            <Input id="name" name="name" value={profile.name} onChange={handleInputChange} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="email">Email</Label>
                            <Input id="email" name="email" type="email" value={profile.email} onChange={handleInputChange} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="phone">Phone</Label>
                            <Input id="phone" name="phone" type="tel" value={profile.phone} onChange={handleInputChange} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="major">Major</Label>
                            <Input id="major" name="major" value={profile.major} onChange={handleInputChange} />
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Notification Preferences</CardTitle>
                        <CardDescription>Manage how you receive notifications</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                                <Label htmlFor="email-notifications">Email Notifications</Label>
                                <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                            </div>
                            <Switch
                                id="email-notifications"
                                checked={profile.notifications.email}
                                onCheckedChange={() => handleNotificationChange('email')}
                            />
                        </div>
                        <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                                <Label htmlFor="sms-notifications">SMS Notifications</Label>
                                <p className="text-sm text-muted-foreground">Receive notifications via SMS</p>
                            </div>
                            <Switch
                                id="sms-notifications"
                                checked={profile.notifications.sms}
                                onCheckedChange={() => handleNotificationChange('sms')}
                            />
                        </div>
                    </CardContent>
                </Card>
            </div>
            <Button onClick={handleSave} className="w-full md:w-auto">Save Changes</Button>
        </div>
    )
}