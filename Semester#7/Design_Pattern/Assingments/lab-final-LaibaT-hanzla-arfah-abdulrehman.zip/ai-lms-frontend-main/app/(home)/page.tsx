'use client';

import { useSession } from 'next-auth/react';
import TeacherDashboard from '@/components/TeacherDashboard';
import StudentDashboard from '@/components/StudentDashboard';

export default function HomePage() {
    const { data: session, status } = useSession();

    if (status === 'loading') {
        return <div>Loading...</div>;
    }

    if (!session) {
        return <div>Please sign in to access your dashboard.</div>;
    }

    // Assuming the user object has a 'role' property
    const userRole = session.user?.role;

    return (
        <div>
            {userRole === 'teacher' ? <TeacherDashboard /> : <StudentDashboard />}
        </div>
    );
}

