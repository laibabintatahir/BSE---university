import type { Metadata } from "next";
import "../globals.css";
import Layout from "@/components/dash-layout";
import { auth } from "@/auth";
import { redirect } from "next/navigation";

export const metadata: Metadata = {
    title: "ClassEdge - AI Assisted LMS",
    description: "ClassEdge is an AI-assisted Learning Management System that provides a personalized learning experience for students and educators.",
};

export default async function LMSLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    const session = await auth();
    if (!session?.user) {
        redirect('/auth/signin')
    }
    return (
        <Layout role={session.user.role}>
            {children}
        </Layout>

    );
}
