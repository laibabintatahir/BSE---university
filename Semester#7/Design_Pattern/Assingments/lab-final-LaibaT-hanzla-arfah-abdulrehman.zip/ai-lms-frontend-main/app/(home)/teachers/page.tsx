import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { TeachersTable, Teacher } from "@/components/admin/teacher/teachers-table"

// This would typically come from your API or database
const dummyTeachers: Teacher[] = [
    {
        id: "1",
        firstName: "John",
        lastName: "Doe",
        specialization: "Mathematics",
        email: "john.doe@example.com",
        employmentStatus: "full-time",
    },
    {
        id: "2",
        firstName: "Jane",
        lastName: "Smith",
        specialization: "Physics",
        email: "jane.smith@example.com",
        employmentStatus: "part-time",
    },
    // Add more dummy data as needed
]

export default function TeachersPage() {
    return (
        <div className="container mx-auto py-10">
            <h1 className="text-2xl font-bold mb-5">Teachers</h1>
            <div className="mb-4 flex justify-between">
                <Link href="/teachers/create">
                    <Button>Add Teacher</Button>
                </Link>
                <Link href="/teachers/batch-create">
                    <Button variant="outline">Batch Add Teachers</Button>
                </Link>
            </div>
            <TeachersTable data={dummyTeachers} />
        </div>
    )
}

