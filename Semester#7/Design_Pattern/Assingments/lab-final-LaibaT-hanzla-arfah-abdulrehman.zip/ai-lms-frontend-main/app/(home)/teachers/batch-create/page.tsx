import { BatchTeacherUpload } from "@/components/admin/teacher/batch-teacher-upload"

export default function BatchCreateTeachersPage() {
    return (
        <div className="container mx-auto py-10">
            <h1 className="text-2xl font-bold mb-5">Batch Create Teachers</h1>
            <BatchTeacherUpload />
        </div>
    )
}

