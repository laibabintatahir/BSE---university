'use client'
import { TeacherForm } from "@/components/admin/teacher/teacher-form"
import { Card, CardContent } from "@/components/ui/card"

export default function CreateTeacherPage() {
    const handleSubmit = (data: any) => {
        // Here you would typically send the data to your API
        console.log(data)
    }

    return (
        <div className="container mx-auto ">
            <Card>
                <CardContent className="p-4 px-6 m-0">
                    <h1 className="text-2xl font-bold mb-5">Create Teacher</h1>
                    <TeacherForm onSubmit={handleSubmit} />
                </CardContent>
            </Card>
        </div>
    )
}

