import React from "react";
import RichTextEditor from "@/components/Teacher/content-generation";

export default function(){
return(
  <div>
    <RichTextEditor/>
  </div>
)

}