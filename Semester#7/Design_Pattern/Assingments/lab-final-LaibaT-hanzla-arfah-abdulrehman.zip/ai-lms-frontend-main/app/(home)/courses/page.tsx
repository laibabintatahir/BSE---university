import Courses from '@/components/Teacher/courses'
import React from 'react'

const CoursesPage = () => {
    return (
        <div><Courses /></div>
    )
}

export default CoursesPage