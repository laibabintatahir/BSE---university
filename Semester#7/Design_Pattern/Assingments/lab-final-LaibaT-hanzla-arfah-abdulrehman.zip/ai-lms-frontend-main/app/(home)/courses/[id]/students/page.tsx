'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";

// Mock data for students
const students = [
    { id: '1', name: 'Alice Johnson', email: 'alice@example.com', registrationNumber: '2023001', grade: 'A', attendance: '95%', lastActive: '2 hours ago' },
    { id: '2', name: 'Bob Smith', email: 'bob@example.com', registrationNumber: '2023002', grade: 'B+', attendance: '88%', lastActive: '1 day ago' },
    { id: '3', name: 'Charlie Brown', email: 'charlie@example.com', registrationNumber: '2023003', grade: 'A-', attendance: '92%', lastActive: '3 hours ago' },
    { id: '4', name: 'Diana Ross', email: 'diana@example.com', registrationNumber: '2023004', grade: 'B', attendance: '85%', lastActive: '5 hours ago' },
    { id: '5', name: 'Edward Norton', email: 'edward@example.com', registrationNumber: '2023005', grade: 'A', attendance: '98%', lastActive: '1 hour ago' },
];

export default function StudentList({ params }: { params: { id: string } }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const studentsPerPage = 10;

    const filteredStudents = students.filter(student =>
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.registrationNumber.includes(searchTerm)
    );

    const indexOfLastStudent = currentPage * studentsPerPage;
    const indexOfFirstStudent = indexOfLastStudent - studentsPerPage;
    const currentStudents = filteredStudents.slice(indexOfFirstStudent, indexOfLastStudent);

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Students Enrolled in Course</CardTitle>
                </CardHeader>
                <CardContent>
                    <Input
                        placeholder="Search students..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="mb-4"
                    />
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Name</TableHead>
                                <TableHead>Registration Number</TableHead>
                                <TableHead>Grade</TableHead>
                                <TableHead>Attendance</TableHead>
                                <TableHead>Last Active</TableHead>
                                <TableHead>Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {currentStudents.map((student) => (
                                <TableRow key={student.id}>
                                    <TableCell className="font-medium">
                                        <div className="flex items-center space-x-3">
                                            <Avatar>
                                                <AvatarImage src={`https://api.dicebear.com/6.x/initials/svg?seed=${student.name}`} />
                                                <AvatarFallback>{student.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                            </Avatar>
                                            <div>
                                                <div>{student.name}</div>
                                                <div className="text-sm text-muted-foreground">{student.email}</div>
                                            </div>
                                        </div>
                                    </TableCell>
                                    <TableCell>{student.registrationNumber}</TableCell>
                                    <TableCell>
                                        <Badge variant="outline">{student.grade}</Badge>
                                    </TableCell>
                                    <TableCell>{student.attendance}</TableCell>
                                    <TableCell>{student.lastActive}</TableCell>
                                    <TableCell>
                                        <Button variant="outline" asChild>
                                            <Link href={`/courses/${params.id}/students/${student.id}`}>
                                                View Details
                                            </Link>
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <div className="mt-4 flex justify-center">
                        <Pagination
                            currentPage={currentPage}
                            totalPages={Math.ceil(filteredStudents.length / studentsPerPage)}
                            onPageChange={setCurrentPage}
                        />
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
