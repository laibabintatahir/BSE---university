'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';

interface Lecture {
    id: string;
    title: string;
    topic: string;
    description: string;
    learningOutcomes: string;
    modules: {
        id: string;
        title: string;
        content: string;
        type: 'text' | 'video' | 'quiz' | 'file';
    }[];
}

export default function EditLecture({ params }: { params: { id: string; lectureId: string } }) {
    const router = useRouter();
    const [lecture, setLecture] = useState<Lecture | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const fetchLecture = async () => {
            try {
                const response = await fetch(`http://localhost:8000/lecture/${params.lectureId}`);
                if (!response.ok) {
                    throw new Error('Failed to fetch lecture');
                }
                const data = await response.json();
                setLecture(data.data);
            } catch (error) {
                console.error('Error fetching lecture:', error);
                toast.error('Failed to load lecture');
            }
        };

        fetchLecture();
    }, [params.lectureId]);

    const handleInputChange = (field: keyof Lecture, value: string) => {
        if (lecture) {
            setLecture({ ...lecture, [field]: value });
        }
    };

    const handleModuleChange = (moduleId: string, field: 'title' | 'content', value: string) => {
        if (lecture) {
            const updatedModules = lecture.modules.map(module =>
                module.id === moduleId ? { ...module, [field]: value } : module
            );
            setLecture({ ...lecture, modules: updatedModules });
        }
    };

    const handleSave = async () => {
        if (!lecture) return;

        setIsLoading(true);
        try {
            const response = await fetch(`http://localhost:8000/lecture/${params.lectureId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(lecture),
            });

            if (!response.ok) {
                throw new Error('Failed to update lecture');
            }

            toast.success('Lecture updated successfully');
            router.push(`/courses/${params.id}/lectures/${params.lectureId}`);
        } catch (error) {
            console.error('Error updating lecture:', error);
            toast.error('Failed to update lecture');
        } finally {
            setIsLoading(false);
        }
    };

    if (!lecture) {
        return <p>Loading...</p>;
    }

    return (
        <div className="container mx-auto p-4">
            <h1 className="text-3xl font-bold mb-4">Edit Lecture: {lecture.title}</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Lecture Details</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div>
                            <Label htmlFor="title">Title</Label>
                            <Input
                                id="title"
                                value={lecture.title}
                                onChange={(e) => handleInputChange('title', e.target.value)}
                            />
                        </div>
                        <div>
                            <Label htmlFor="topic">Topic</Label>
                            <Input
                                id="topic"
                                value={lecture.topic}
                                onChange={(e) => handleInputChange('topic', e.target.value)}
                            />
                        </div>
                        <div>
                            <Label htmlFor="description">Description</Label>
                            <Textarea
                                id="description"
                                value={lecture.description}
                                onChange={(e) => handleInputChange('description', e.target.value)}
                            />
                        </div>
                        <div>
                            <Label htmlFor="learningOutcomes">Learning Outcomes</Label>
                            <Textarea
                                id="learningOutcomes"
                                value={lecture.learningOutcomes}
                                onChange={(e) => handleInputChange('learningOutcomes', e.target.value)}
                            />
                        </div>
                    </div>
                </CardContent>
            </Card>

            <h2 className="text-2xl font-bold mt-8 mb-4">Modules</h2>
            {lecture.modules.map((module) => (
                <Card key={module.id} className="mb-4">
                    <CardHeader>
                        <CardTitle>
                            <Input
                                value={module.title}
                                onChange={(e) => handleModuleChange(module.id, 'title', e.target.value)}
                            />
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Textarea
                            value={module.content}
                            onChange={(e) => handleModuleChange(module.id, 'content', e.target.value)}
                            rows={6}
                        />
                    </CardContent>
                </Card>
            ))}

            <div className="mt-8">
                <Button onClick={handleSave} disabled={isLoading}>
                    {isLoading ? (
                        <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                        </>
                    ) : (
                        'Save Changes'
                    )}
                </Button>
            </div>
        </div>
    );
}

