import React from "react";
import LectureView from "@/components/Teacher/view-lecture";
export default function page({ params: { id, lectureId } }: { params: { id: string, lectureId: string } }) {

  return (

    <div>
      <LectureView
        // lectureId={lectureId}
        params={{ id, lectureId }}
      />
    </div>

  );

}