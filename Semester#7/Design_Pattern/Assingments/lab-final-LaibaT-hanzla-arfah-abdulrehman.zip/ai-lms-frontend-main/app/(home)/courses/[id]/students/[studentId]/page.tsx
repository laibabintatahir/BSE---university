'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Mock data for the student
const studentData = {
    id: '1',
    name: 'Alice Johnson',
    email: 'alice@example.com',
    registrationNumber: '2023001',
    grade: 'A',
    attendance: '95%',
    lastActive: '2 hours ago',
    overallProgress: 85,
    assignments: [
        { id: 1, name: 'Assignment 1', score: 90, totalScore: 100 },
        { id: 2, name: 'Assignment 2', score: 85, totalScore: 100 },
        { id: 3, name: 'Assignment 3', score: 95, totalScore: 100 },
    ],
    quizzes: [
        { id: 1, name: 'Quiz 1', score: 8, totalScore: 10 },
        { id: 2, name: 'Quiz 2', score: 9, totalScore: 10 },
        { id: 3, name: 'Quiz 3', score: 7, totalScore: 10 },
    ],
    performanceData: [
        { week: 'Week 1', score: 85 },
        { week: 'Week 2', score: 88 },
        { week: 'Week 3', score: 92 },
        { week: 'Week 4', score: 90 },
        { week: 'Week 5', score: 95 },
    ],
};

export default function StudentDetails({ params }: { params: { id: string, studentId: string } }) {
    const [activeTab, setActiveTab] = useState('overview');

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex items-center space-x-4">
                        <Avatar className="w-16 h-16">
                            <AvatarImage src={`https://api.dicebear.com/6.x/initials/svg?seed=${studentData.name}`} />
                            <AvatarFallback>{studentData.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div>
                            <CardTitle>{studentData.name}</CardTitle>
                            <p className="text-sm text-muted-foreground">{studentData.email}</p>
                            <p className="text-sm text-muted-foreground">Registration: {studentData.registrationNumber}</p>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="flex flex-col items-center">
                            <Badge variant="outline" className="mb-2">{studentData.grade}</Badge>
                            <p className="text-sm text-muted-foreground">Current Grade</p>
                        </div>
                        <div className="flex flex-col items-center">
                            <p className="font-bold mb-2">{studentData.attendance}</p>
                            <p className="text-sm text-muted-foreground">Attendance Rate</p>
                        </div>
                        <div className="flex flex-col items-center">
                            <p className="font-bold mb-2">{studentData.lastActive}</p>
                            <p className="text-sm text-muted-foreground">Last Active</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="assignments">Assignments</TabsTrigger>
                    <TabsTrigger value="quizzes">Quizzes</TabsTrigger>
                </TabsList>
                <TabsContent value="overview">
                    <Card>
                        <CardHeader>
                            <CardTitle>Overall Progress</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Progress value={studentData.overallProgress} className="w-full" />
                            <p className="mt-2 text-center">{studentData.overallProgress}% Complete</p>
                            <div className="mt-4">
                                <ResponsiveContainer width="100%" height={300}>
                                    <LineChart data={studentData.performanceData}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="week" />
                                        <YAxis />
                                        <Tooltip />
                                        <Line type="monotone" dataKey="score" stroke="#8884d8" />
                                    </LineChart>
                                </ResponsiveContainer>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="assignments">
                    <Card>
                        <CardHeader>
                            <CardTitle>Assignments</CardTitle>
                        </CardHeader>
                        <CardContent>
                            {studentData.assignments.map((assignment) => (
                                <div key={assignment.id} className="mb-4">
                                    <div className="flex justify-between items-center mb-2">
                                        <p>{assignment.name}</p>
                                        <Badge variant="outline">{assignment.score}/{assignment.totalScore}</Badge>
                                    </div>
                                    <Progress value={(assignment.score / assignment.totalScore) * 100} className="w-full" />
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="quizzes">
                    <Card>
                        <CardHeader>
                            <CardTitle>Quizzes</CardTitle>
                        </CardHeader>
                        <CardContent>
                            {studentData.quizzes.map((quiz) => (
                                <div key={quiz.id} className="mb-4">
                                    <div className="flex justify-between items-center mb-2">
                                        <p>{quiz.name}</p>
                                        <Badge variant="outline">{quiz.score}/{quiz.totalScore}</Badge>
                                    </div>
                                    <Progress value={(quiz.score / quiz.totalScore) * 100} className="w-full" />
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            <Dialog>
                <DialogTrigger asChild>
                    <Button>View Detailed Metrics</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <DialogTitle>Detailed Metrics</DialogTitle>
                        <DialogDescription>
                            Comprehensive view of {studentData.name}'s performance metrics.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <p className="text-sm font-medium col-span-2">Total Study Time:</p>
                            <p className="col-span-2">45 hours</p>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <p className="text-sm font-medium col-span-2">Average Quiz Score:</p>
                            <p className="col-span-2">85%</p>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <p className="text-sm font-medium col-span-2">Participation Rate:</p>
                            <p className="col-span-2">92%</p>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <p className="text-sm font-medium col-span-2">Improvement Trend:</p>
                            <p className="col-span-2">Positive</p>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}
