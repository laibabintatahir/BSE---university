'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pagination } from "@/components/ui/pagination";
import { LectureList } from '@/components/Teacher/lecture-list';
import { StudentLectureList } from '@/components/Student/student-lecture-list';
import { BookOpen, Users, Clock } from 'lucide-react';

interface Lecture {
  id: string;
  title: string;
  status: 'saved' | 'published';
}

interface CourseData {
  id: string;
  title: string;
  code: string;
  instructor: string;
  totalLectures: number;
  publishedLectures: number;
  description: string;
  enrolledStudents: number;
  duration: string;
}

const courseData: CourseData = {
  id: '1',
  title: 'Introduction to Computer Science',
  code: 'CS101',
  instructor: 'Dr. Jane Smith',
  totalLectures: 20,
  publishedLectures: 15,
  description: 'This course provides a comprehensive introduction to computer science, covering fundamental concepts, programming basics, and problem-solving techniques.',
  enrolledStudents: 150,
  duration: '12 weeks',
};

export default function CourseDetails({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { data: session } = useSession();
  const [activeTab, setActiveTab] = useState('all');
  const [lectures, setLectures] = useState<Lecture[]>([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');

  const isTeacher = session?.user?.role === 'teacher';

  useEffect(() => {
    fetchLectures();
  }, [page, searchTerm, filter]);

  const fetchLectures = async () => {
    try {
      const response = await fetch(`http://localhost:8000/lecture?page=${page}&limit=10`);
      if (!response.ok) throw new Error('Failed to fetch lectures');

      const data = await response.json();
      setLectures(
        data.data.map((lecture: any) => ({
          id: lecture._id,
          title: lecture.title,
          status: lecture.isPublished ? 'published' : 'saved',
        }))
      );
      setTotalPages(data.totalPages || 1);
    } catch (error) {
      console.error('Error fetching lectures:', error);
    }
  };

  const handleCreateLecture = () => {
    router.push(`/courses/${params.id}/create-lecture`);
  };

  const handleEditLecture = (lectureId: string) => {
    router.push(`/courses/${params.id}/view-lecture/${lectureId}/edit`);
  };

  const handleViewLecture = (lectureId: string) => {
    router.push(`/courses/${params.id}/view-lecture/${lectureId}`);
  };

  const handleDeleteLecture = async (lectureId: string) => {
    try {
      await fetch(`/api/lectures/${lectureId}`, { method: 'DELETE' });
      fetchLectures();
    } catch (error) {
      console.error('Error deleting lecture:', error);
    }
  };

  const handlePublishLecture = async (lectureId: string) => {
    try {
      await fetch(`/api/lectures/${lectureId}/publish`, { method: 'POST' });
      fetchLectures();
    } catch (error) {
      console.error('Error publishing lecture:', error);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-3xl font-bold tracking-tight">{courseData.title}</h2>
        {isTeacher && (
          <Button
            className="bg-primary hover:bg-secondary hover:text-primary w-full sm:w-auto"
            onClick={handleCreateLecture}
          >
            Create Lecture
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{courseData.code}</CardTitle>
          <CardDescription>Instructor: {courseData.instructor}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="flex items-center">
              <BookOpen className="mr-2" />
              <div>
                <p className="font-semibold">{courseData.publishedLectures} / {courseData.totalLectures}</p>
                <p className="text-sm text-muted-foreground">Lectures Published</p>
              </div>
            </div>
            <div className="flex items-center">
              <Users className="mr-2" />
              <div>
                <p className="font-semibold">{courseData.enrolledStudents}</p>
                <p className="text-sm text-muted-foreground">Enrolled Students</p>
              </div>
            </div>
            <div className="flex items-center">
              <Clock className="mr-2" />
              <div>
                <p className="font-semibold">{courseData.duration}</p>
                <p className="text-sm text-muted-foreground">Course Duration</p>
              </div>
            </div>
          </div>
          <p>{courseData.description}</p>
        </CardContent>
      </Card>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
        <Input
          placeholder="Search lectures..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full sm:w-64"
        />
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-full sm:w-40">
            <SelectValue placeholder="Filter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Lectures</SelectItem>
            <SelectItem value="saved">Saved</SelectItem>
            <SelectItem value="published">Published</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isTeacher ? (
        <Tabs defaultValue="all" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Lectures</TabsTrigger>
            <TabsTrigger value="saved">Saved</TabsTrigger>
            <TabsTrigger value="published">Published</TabsTrigger>
          </TabsList>
          <TabsContent value="all">
            <LectureList
              lectures={lectures}
              onEdit={handleEditLecture}
              onView={handleViewLecture}
              onDelete={handleDeleteLecture}
              onPublish={handlePublishLecture}
            />
          </TabsContent>
          <TabsContent value="saved">
            <LectureList
              lectures={lectures.filter((lecture) => lecture.status === 'saved')}
              onEdit={handleEditLecture}
              onView={handleViewLecture}
              onDelete={handleDeleteLecture}
              onPublish={handlePublishLecture}
            />
          </TabsContent>
          <TabsContent value="published">
            <LectureList
              lectures={lectures.filter((lecture) => lecture.status === 'published')}
              onView={handleViewLecture}
              onDelete={handleDeleteLecture}
            />
          </TabsContent>
        </Tabs>
      ) : (
        <StudentLectureList lectures={lectures} onView={handleViewLecture} />
      )}

      <Pagination
        currentPage={page}
        totalPages={totalPages}
        onPageChange={setPage}
      />
    </div>
  );
}
