import { Calendar, Clock } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const timetableData = [
    {
        id: 1, day: 'Monday', classes: [
            { id: 1, subject: 'Mathematics', time: '09:00 AM', duration: '1h', room: 'Room 101' },
            { id: 2, subject: 'Physics', time: '11:00 AM', duration: '2h', room: 'Lab 3' },
            { id: 3, subject: 'Computer Science', time: '02:00 PM', duration: '1h 30m', room: 'Computer Lab' },
        ]
    },
    {
        id: 2, day: 'Tuesday', classes: [
            { id: 4, subject: 'English Literature', time: '10:00 AM', duration: '1h 30m', room: 'Room 205' },
            { id: 5, subject: 'Chemistry', time: '01:00 PM', duration: '2h', room: 'Lab 2' },
        ]
    },
    {
        id: 3, day: 'Wednesday', classes: [
            { id: 6, subject: 'History', time: '09:00 AM', duration: '1h 30m', room: 'Room 301' },
            { id: 7, subject: 'Physical Education', time: '11:00 AM', duration: '1h', room: 'Gym' },
            { id: 8, subject: 'Mathematics', time: '02:00 PM', duration: '1h', room: 'Room 101' },
        ]
    },
    {
        id: 4, day: 'Thursday', classes: [
            { id: 9, subject: 'Biology', time: '10:00 AM', duration: '2h', room: 'Lab 1' },
            { id: 10, subject: 'Computer Science', time: '01:00 PM', duration: '1h 30m', room: 'Computer Lab' },
        ]
    },
    {
        id: 5, day: 'Friday', classes: [
            { id: 11, subject: 'Physics', time: '09:00 AM', duration: '2h', room: 'Lab 3' },
            { id: 12, subject: 'English Literature', time: '11:30 AM', duration: '1h 30m', room: 'Room 205' },
            { id: 13, subject: 'Mathematics', time: '02:00 PM', duration: '1h', room: 'Room 101' },
        ]
    },
]

export default function Timetable() {
    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold tracking-tight">Weekly Timetable</h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {timetableData.map((day) => (
                    <Card key={day.id}>
                        <CardHeader>
                            <CardTitle>{day.day}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                {day.classes.map((classItem) => (
                                    <div key={classItem.id} className="flex items-center space-x-4">
                                        <div className="flex-shrink-0">
                                            <Badge variant="outline" className="text-primary">

                                                {classItem.time}
                                            </Badge>
                                        </div>
                                        <div>
                                            <p className="text-sm font-medium leading-none">{classItem.subject}</p>
                                            <p className="text-sm text-muted-foreground">{classItem.room}</p>
                                        </div>
                                        <div className="ml-auto flex items-center space-x-2 text-muted-foreground">
                                            <Clock className="h-4 w-4" />
                                            <span className="text-xs">{classItem.duration}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}