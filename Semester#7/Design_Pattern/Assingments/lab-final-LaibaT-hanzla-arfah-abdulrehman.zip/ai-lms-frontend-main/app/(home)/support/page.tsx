'use client'
import { useState } from 'react'
import { HelpCircle, MessageSquare, Phone, Mail } from 'lucide-react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const faqItems = [
    { question: "How do I reset my password?", answer: "You can reset your password by clicking on the 'Forgot Password' link on the login page and following the instructions sent to your email." },
    { question: "How can I view my grades?", answer: "You can view your grades by navigating to the 'Grades' section in the sidebar menu. There you'll find a breakdown of your performance in each course." },
    { question: "What should I do if I can't access a course?", answer: "If you're having trouble accessing a course, first ensure you're properly enrolled. If the issue persists, contact your instructor or the IT support team." },
]

export default function Support() {
    const [selectedCategory, setSelectedCategory] = useState('')

    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold tracking-tight">Support</h2>
            <div className="grid  gap-4 md:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle>Frequently Asked Questions</CardTitle>
                        <CardDescription>Find quick answers to common questions</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {faqItems.map((item, index) => (
                                <div key={index} className="space-y-2">
                                    <h3 className="font-semibold flex items-center">
                                        <HelpCircle className="h-5 w-5 mr-2 text-primary" />
                                        {item.question}
                                    </h3>
                                    <p className="text-sm text-muted-foreground pl-7">{item.answer}</p>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Contact Support</CardTitle>
                        <CardDescription>Get in touch with our support team</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form className="space-y-4">
                            <div className="space-y-2">
                                <label htmlFor="category" className="text-sm font-medium">Category</label>
                                <Select onValueChange={setSelectedCategory}>
                                    <SelectTrigger id="category">
                                        <SelectValue placeholder="Select a category" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="technical">Technical Issue</SelectItem>
                                        <SelectItem value="account">Account Management</SelectItem>
                                        <SelectItem value="course">Course-related</SelectItem>
                                        <SelectItem value="other">Other</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <label htmlFor="subject" className="text-sm font-medium">Subject</label>
                                <Input id="subject" placeholder="Brief description of your issue" />
                            </div>
                            <div className="space-y-2">
                                <label htmlFor="message" className="text-sm font-medium">Message</label>
                                <Textarea id="message" placeholder="Provide details about your issue or question" />
                            </div>
                        </form>
                    </CardContent>
                    <CardFooter>
                        <Button className="w-full">Submit Support Ticket</Button>
                    </CardFooter>
                </Card>
            </div>
            <Card>
                <CardHeader>
                    <CardTitle>Other Ways to Reach Us</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col md:flex-row justify-between">
                    <div className="flex items-center space-x-2 mb-4 md:mb-0">
                        <MessageSquare className="h-5 w-5 text-primary" />
                        <span>Live Chat: Available 24/7</span>
                    </div>
                    <div className="flex items-center space-x-2 mb-4 md:mb-0">
                        <Phone className="h-5 w-5 text-primary" />
                        <span>Phone: +1 (555) 123-4567</span>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Mail className="h-5 w-5 text-primary" />
                        <span>Email: support@edulmssystem.com</span>
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}