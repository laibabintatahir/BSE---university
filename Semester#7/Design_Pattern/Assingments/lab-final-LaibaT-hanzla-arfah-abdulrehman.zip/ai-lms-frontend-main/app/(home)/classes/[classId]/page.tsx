import { ClassDetails } from "@/components/class/class-details"
import { StudentsList } from "@/components/class/students-list"
import { SubjectsList } from "@/components/class/subjects-list"
import { Timetable } from "@/components/class/timetable"

// This would typically come from your API or database
const dummyClassData = {
    id: "1",
    name: "9th",
    section: "A",
    incharge: "John Doe",
    studentsCount: 30,
    subjectsCount: 6,
}

const dummyStudents = [
    { id: "1", name: "Alice Johnson", rollNumber: "001" },
    { id: "2", name: "Bob Smith", rollNumber: "002" },
    { id: "3", name: "Charlie Brown", rollNumber: "003" },
]

const dummySubjects = [
    { id: "1", name: "Mathematics", teacher: "Jane Doe" },
    { id: "2", name: "Science", teacher: "Alan Turing" },
    { id: "3", name: "English", teacher: "William Shakespeare" },
]

const dummyTimetable = {
    Monday: [
        { time: "9:00 AM", subject: "Mathematics" },
        { time: "10:00 AM", subject: "Science" },
        { time: "11:00 AM", subject: "English" },
    ],
    Tuesday: [
        { time: "9:00 AM", subject: "Science" },
        { time: "10:00 AM", subject: "English" },
        { time: "11:00 AM", subject: "Mathematics" },
    ],
    Wednesday: [
        { time: "9:00 AM", subject: "English" },
        { time: "10:00 AM", subject: "Mathematics" },
        { time: "11:00 AM", subject: "Science" },
    ],
    Thursday: [
        { time: "9:00 AM", subject: "Mathematics" },
        { time: "10:00 AM", subject: "Science" },
        { time: "11:00 AM", subject: "English" },
    ],
    Friday: [
        { time: "9:00 AM", subject: "Science" },
        { time: "10:00 AM", subject: "English" },
        { time: "11:00 AM", subject: "Mathematics" },
    ],
}

export default function ClassPage({ params }: { params: { classId: string } }) {
    // In a real application, you would fetch the class data using the classId
    // For now, we'll use the dummy data

    return (
        <div className="container mx-auto ">
            <h1 className="text-3xl font-bold mb-8">Class Details</h1>
            <div className="grid gap-8 md:grid-cols-2">
                <ClassDetails classData={dummyClassData} />
                <StudentsList students={dummyStudents} />
                <SubjectsList subjects={dummySubjects} />
                <Timetable timetable={dummyTimetable} />
            </div>
        </div>
    )
}

