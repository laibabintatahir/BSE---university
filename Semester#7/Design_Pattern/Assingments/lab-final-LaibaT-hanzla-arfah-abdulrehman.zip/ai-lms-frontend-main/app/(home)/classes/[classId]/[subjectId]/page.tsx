import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Edit, Users, BookOpen } from 'lucide-react'

// This would typically come from your API or database
const dummySubjectData = {
    id: "1",
    name: "Mathematics",
    teacher: "John Doe",
    description: "Advanced mathematics covering algebra, geometry, and calculus.",
    credits: 5,
    studentsCount: 30,
}

export default function SubjectPage({ params }: { params: { classId: string, subjectId: string } }) {
    // In a real application, you would fetch the subject data using the classId and subjectId
    // For now, we'll use the dummy data

    return (
        <div className="container mx-auto ">
            <h1 className="text-3xl font-bold mb-8">Subject Details</h1>
            <Card>
                <CardHeader>
                    <CardTitle>{dummySubjectData.name}</CardTitle>
                    <CardDescription>Teacher: {dummySubjectData.teacher}</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="mb-4">{dummySubjectData.description}</p>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="flex items-center">
                            <BookOpen className="mr-2" />
                            <span>{dummySubjectData.credits} Credits</span>
                        </div>
                        <div className="flex items-center">
                            <Users className="mr-2" />
                            <span>{dummySubjectData.studentsCount} Students</span>
                        </div>
                    </div>
                    <Button className="mr-2">
                        <Edit className="mr-2 h-4 w-4" /> Edit Subject
                    </Button>
                    <Button variant="outline">View Students</Button>
                </CardContent>
            </Card>
        </div>
    )
}

