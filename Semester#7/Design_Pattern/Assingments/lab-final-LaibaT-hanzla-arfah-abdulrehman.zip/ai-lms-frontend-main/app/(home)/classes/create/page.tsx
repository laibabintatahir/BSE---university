import { CreateClassForm } from "@/components/class/create-class-form"
import { Card, CardContent } from "@/components/ui/card"

export default function CreateClassPage() {
    return (
        <div className="container mx-auto ">
            <Card>
                <CardContent className="p-4">
                    <h1 className="text-3xl font-bold ">Create New Class</h1>
                    <CreateClassForm />
                </CardContent>
            </Card>
        </div>
    )
}

