import { auth } from '@/auth'
import { ClassesTable, Class } from '@/components/class/classes-table'
// import { CreateClassButton } from '@/components/create-class-button'
import { Button } from '@/components/ui/button'
import { PlusCircle } from 'lucide-react'
import Link from 'next/link'

const dummyClasses: Class[] = [
    {
        id: '1',
        name: '9th',
        section: 'A',
        incharge: 'John Doe',
        studentsCount: 30,
        subjectsCount: 6,
    },
    {
        id: '2',
        name: '10th',
        section: 'Rose',
        incharge: 'Jane Smith',
        studentsCount: 28,
        subjectsCount: 7,
    },
    {
        id: '3',
        name: '12th',
        section: 'Emerald',
        incharge: 'Bob Johnson',
        studentsCount: 25,
        subjectsCount: 5,
    },
]

export default async function ClassListPage() {
    const session = await auth()

    if (!session || !session.user.role.includes('admin')) {
        return <div>Access Denied</div>
    }

    return (
        <div className="container mx-auto ">
            <div className='flex justify-between w-full items-center'>
                <h1 className="text-2xl font-bold mb-5">Classes</h1>
                <Button>
                    <Link href="/classes/create" className='flex items-center'>
                        <PlusCircle className="mr-2 h-4 w-4" /> Create Class
                    </Link>
                </Button>
            </div>
            <div className="mb-4">

            </div>
            <ClassesTable data={dummyClasses} />
        </div>
    )
}



//What information of a Class do i wanna handle ?
//A Class has an identifier, a name. e.g. it can be Class: 9th A, 12 Emerald, 10th Rose
// A Class May have a section for instance A, B, Rose, Tulip, Emerald etc
// A Class will have a Class Incharge/Teacher
// A Class will have a list of students
// A Class will have a list of subjects
// A Class will not have a list of assignments or grades, those will be handled by the subjects
// A Class will have a Timetable

//What operations do i wanna perform on a Class?
//Create a Class
//Update a Class
//Delete a Class
//Assign a Teacher to a Class
//Add a Student to a Class
//Remove a Student from a Class
//Add a Subject to a Class
//Remove a Subject from a Class
//View the Timetable of a Class
//Update the Timetable of a Class
//View the list of students in a Class
//View the list of subjects in a Class

//What are the different ways in which i can view a Class?
//View a list of all Classes
//View a single Class
//View a list of all students in a Class
//View a list of all subjects in a Class
//View the Timetable of a Class
//View the list of assignments in a Class