"use client"

import { useState, useRef, useEffect } from 'react'
import { Send, Bot, Lightbulb, User, Sparkles } from 'lucide-react'
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import ReactMarkdown from 'react-markdown'
import { motion, AnimatePresence } from 'framer-motion'
import dayjs from 'dayjs'

// Constants for conversation memory and summarization
const MAX_MESSAGES = 10; // Limit to the last 10 messages for context
const SUMMARY_THRESHOLD = 30; // Summarize when messages exceed 30
const memory: string[] = []; // Memory for important facts

// Helper function to summarize messages
interface Message {
    role: 'user' | 'assistant';
    content: string;
    timestamp: Date;
}

const summarizeMessages = (messages: Message[]): Message => {
    const summaryContent = messages.map(m => `${m.role}: ${m.content}`).join(' ');
    return { role: 'assistant', content: `Summary: ${summaryContent}`, timestamp: new Date() };
};

// Function to manage and limit context
interface LimitedContextMessage extends Message { }

const getLimitedContext = (messages: Message[]): LimitedContextMessage[] => {
    if (messages.length > SUMMARY_THRESHOLD) {
        const summary = summarizeMessages(messages.slice(0, SUMMARY_THRESHOLD));
        return [summary, ...messages.slice(SUMMARY_THRESHOLD)];
    }
    return messages.slice(-MAX_MESSAGES);
};

// Function to add important facts to memory
const addToMemory = (message: Message) => {
    if (message.role === 'user' && message.content.toLowerCase().includes("remember")) {
        memory.push(message.content.replace("Remember", "").trim());
    }
};

export default function AIAssistant() {
    const [messages, setMessages] = useState<Message[]>([
        { role: 'assistant', content: '👋 Hello! I\'m here to assist you with your studies. Ask me anything or request study tips, and I\'ll do my best to help!', timestamp: new Date() },
    ])
    const [input, setInput] = useState('')
    const [isTyping, setIsTyping] = useState(false)
    const scrollAreaRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (scrollAreaRef.current) {
            scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
        }
    }, [messages, isTyping])

    const handleSendMessage = async () => {
        if (!input.trim()) return

        const timestamp = new Date()

        // Add the user message to the chat
        setMessages(prev => [...prev, { role: 'user', content: input, timestamp }])
        addToMemory({ role: 'user', content: input, timestamp }); // Add important facts to memory
        setInput('')

        // Add a placeholder for the assistant's typing message
        setIsTyping(true)
        let accumulatedText = ''

        try {
            // Prepare limited context
            const limitedMessages: Message[] = [...memory.map(content => ({ role: 'user' as const, content, timestamp: new Date() })), ...getLimitedContext(messages), { role: 'user' as const, content: input, timestamp }];

            const response = await fetch('http://localhost:11434/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    model: 'llama3.1:8b',
                    messages: limitedMessages, // Send the limited context with memory
                }),
            })

            const reader = response.body!.getReader()
            let assistantResponse: Message = { role: 'assistant', content: '', timestamp: new Date() }
            setMessages(prev => [...prev, assistantResponse])

            while (true) {
                const { done, value } = await reader.read()
                if (done) break

                const chunk = new TextDecoder().decode(value)
                const lines = chunk.split('\n')

                for (const line of lines) {
                    if (line.trim()) {
                        try {
                            const json = JSON.parse(line)
                            if (json.message && json.message.content) {
                                accumulatedText += json.message.content

                                // Update only the latest assistant message with accumulated content
                                setMessages(prev => {
                                    const updatedMessages = [...prev]
                                    updatedMessages[updatedMessages.length - 1] = {
                                        role: 'assistant',
                                        content: accumulatedText,
                                        timestamp: new Date(),
                                    }
                                    return updatedMessages
                                })
                            }
                        } catch (err) {
                            console.error('Failed to parse line:', line, err)
                        }
                    }
                }
            }
        } catch (error) {
            console.error("Error in handleSendMessage:", error)
            setMessages(prev => [
                ...prev,
                { role: 'assistant', content: 'Sorry, I couldn\'t process that request.', timestamp: new Date() }
            ])
        } finally {
            setIsTyping(false)
        }
    }

    const formatTimestamp = (timestamp: Date) => {
        return dayjs(timestamp).format('h:mm A')
    }

    return (
        <div className=" lg:p-4 flex flex-col items-center justify-center">
            <Card className="w-full  lg:h-[85vh] h-[92vh] flex flex-col shadow-2xl shadow-purple-200 lg:rounded-2xl rounded-none overflow-hidden border-2 border-purple-200">
                <CardContent className="flex-1 overflow-hidden bg-white">
                    <ScrollArea className="h-full px-6 ">
                        <CardHeader className="bg-white py-6 my-2 px-8 border-b border-purple-100">
                            <CardTitle className="text-5xl font-bold tracking-tight text-center">
                                <span className="bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent">Classy</span>
                            </CardTitle>
                            <CardDescription className="text-lg text-center text-gray-600 mt-2">
                                Your personal guide to academic excellence
                            </CardDescription>
                        </CardHeader>
                        <AnimatePresence>
                            {messages.map((message, index) => (
                                <motion.div
                                    key={index}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: -20 }}
                                    transition={{ duration: 0.3 }}
                                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
                                    ref={index === messages.length - 1 ? scrollAreaRef : undefined}
                                >
                                    <div className={`flex items-start max-w-[80%] ${message.role === 'user' ? 'bg-purple-500 text-white' : 'bg-blue-50 text-gray-800'} rounded-2xl p-4 shadow-md`}>
                                        {message.role === 'assistant' ? (
                                            <Avatar className="mr-3 h-10 w-10 border-2 border-blue-200">
                                                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="AI Assistant" />
                                                <AvatarFallback><Sparkles className="h-6 w-6 text-blue-500" /></AvatarFallback>
                                            </Avatar>
                                        ) : (
                                            <Avatar className="ml-3 h-10 w-10 order-2 border-2 border-purple-200">
                                                <AvatarFallback><User className="h-6 w-6 text-purple-500" /></AvatarFallback>
                                            </Avatar>
                                        )}
                                        <div className={`flex flex-col ${message.role === 'user' ? 'order-1 mr-3 items-end' : 'items-start'}`}>
                                            <ReactMarkdown className="text-sm prose max-w-none">{message.content}</ReactMarkdown>
                                            <span className={`text-xs mt-2 ${message.role === 'user' ? 'text-purple-200' : 'text-gray-500'}`}>{formatTimestamp(message.timestamp)}</span>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                        {isTyping && (
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                className="flex justify-start mb-4"
                            >
                                <div className="bg-blue-50 text-gray-800 rounded-2xl p-4 shadow-md">
                                    <div className="flex space-x-2">
                                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                                    </div>
                                    <span className="text-xs text-gray-500 mt-2 block">AI is thinking...</span>
                                </div>
                            </motion.div>
                        )}
                    </ScrollArea>
                </CardContent>
                <CardFooter className="p-4 bg-white border-t border-purple-100">
                    <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }} className="flex w-full space-x-2">
                        <Input
                            placeholder="Ask me anything about your studies..."
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            className="flex-1 rounded-full border-2 border-purple-100 focus:border-purple-300 focus:ring-2 focus:ring-purple-200 transition-all duration-300"
                        />
                        <Button type="submit" className="rounded-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 transition-all duration-300 shadow-md hover:shadow-lg">
                            <Send className="h-5 w-5" />
                            <span className="sr-only">Send message</span>
                        </Button>
                    </form>
                </CardFooter>
            </Card>
        </div>
    )
}