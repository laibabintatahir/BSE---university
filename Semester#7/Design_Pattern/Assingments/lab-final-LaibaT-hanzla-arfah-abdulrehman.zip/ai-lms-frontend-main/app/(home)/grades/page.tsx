"use client"

import { useState } from "react"
import Link from "next/link"
import { BarChart, BookOpen, TrendingUp, MoreVertical } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type Grade = 'A' | 'A-' | 'B+' | 'B' | 'B-' | 'C+' | 'C'

const courses = [
    { id: 1, name: 'Mathematics', code: 'MATH301', grade: 'A' as Grade, score: 92, credits: 4 },
    { id: 2, name: 'Physics', code: 'PHYS201', grade: 'B+' as Grade, score: 87, credits: 4 },
    { id: 3, name: 'Computer Science', code: 'CS101', grade: 'A-' as Grade, score: 90, credits: 3 },
    { id: 4, name: 'English Literature', code: 'ENG202', grade: 'B' as Grade, score: 84, credits: 3 },
    { id: 5, name: 'Chemistry', code: 'CHEM101', grade: 'A' as Grade, score: 95, credits: 4 },
]

const calculateGPA = (courses: { id: number, name: string, code: string, grade: Grade, score: number, credits: number }[]) => {
    const gradePoints = { 'A': 4, 'A-': 3.7, 'B+': 3.3, 'B': 3, 'B-': 2.7, 'C+': 2.3, 'C': 2 }
    const totalCredits = courses.reduce((sum, course) => sum + course.credits, 0)
    const totalGradePoints = courses.reduce((sum, course) => sum + gradePoints[course.grade] * course.credits, 0)
    return (totalGradePoints / totalCredits).toFixed(2)
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8']

export default function Grades() {
    const overallGPA = calculateGPA(courses)
    const totalCredits = courses.reduce((sum, course) => sum + course.credits, 0)

    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold tracking-tight">Academic Progress</h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Overall GPA</CardTitle>
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{overallGPA}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Credits</CardTitle>
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{totalCredits}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Courses Enrolled</CardTitle>
                        <BarChart className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{courses.length}</div>
                    </CardContent>
                </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {courses.map((course, index) => (
                    <Card key={course.id}>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">{course.name}</CardTitle>
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" className="h-8 w-8 p-0">
                                        <span className="sr-only">Open menu</span>
                                        <MoreVertical className="h-4 w-4" />
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                    <DropdownMenuItem>View details</DropdownMenuItem>
                                    <DropdownMenuItem>View assignments</DropdownMenuItem>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem>Contact instructor</DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </CardHeader>
                        <CardContent>
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-xs text-muted-foreground">{course.code}</p>
                                    <div className="mt-2 flex items-center">
                                        <Badge variant="outline" className="text-lg mr-2">
                                            {course.grade}
                                        </Badge>
                                        <span className="text-2xl font-bold">{course.score}%</span>
                                    </div>
                                </div>
                                <div className="h-16 w-16">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie
                                                data={[{ value: course.score }, { value: 100 - course.score }]}
                                                innerRadius={25}
                                                outerRadius={32}
                                                paddingAngle={2}
                                                dataKey="value"
                                            >
                                                <Cell fill={COLORS[index % COLORS.length]} />
                                                <Cell fill="#f3f4f6" />
                                            </Pie>
                                        </PieChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                            <Progress value={course.score} className="mt-2" />
                            <div className="mt-2 text-right">
                                <Link href={`/courses/${course.id}`} className="text-sm text-blue-600 hover:underline">
                                    View course
                                </Link>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
