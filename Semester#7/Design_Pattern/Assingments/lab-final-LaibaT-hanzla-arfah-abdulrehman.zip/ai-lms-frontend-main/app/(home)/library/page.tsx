import { Book, Download, Search } from 'lucide-react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

const books = [
    { id: 1, title: 'Introduction to Computer Science', author: 'John Smith', category: 'Computer Science', available: true },
    { id: 2, title: 'Advanced Calculus', author: 'Jane Doe', category: 'Mathematics', available: false },
    { id: 3, title: 'Modern Physics', author: 'Albert Einstein', category: 'Physics', available: true },
    { id: 4, title: 'The Art of Programming', author: 'Donald Knuth', category: 'Computer Science', available: true },
    { id: 5, title: 'Organic Chemistry', author: 'Marie Curie', category: 'Chemistry', available: false },
]

export default function Library() {
    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold tracking-tight">Library</h2>
            <div className="flex space-x-2">
                <Input placeholder="Search books..." className="max-w-sm" />
                <Button>
                    <Search className="h-4 w-4 mr-2" />
                    Search
                </Button>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {books.map((book) => (
                    <Card key={book.id}>
                        <CardHeader>
                            <CardTitle>{book.title}</CardTitle>
                            <CardDescription>{book.author}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Badge variant={book.category === 'Computer Science' ? 'default' : book.category === 'Mathematics' ? 'secondary' : 'outline'}>
                                {book.category}
                            </Badge>
                            <p className="mt-2 text-sm text-muted-foreground">
                                Status: {book.available ? 'Available' : 'Checked Out'}
                            </p>
                        </CardContent>
                        <CardFooter>
                            <Button variant={book.available ? 'default' : 'secondary'} className="w-full" disabled={!book.available}>
                                {book.available ? (
                                    <>
                                        <Download className="h-4 w-4 mr-2" />
                                        Borrow
                                    </>
                                ) : 'Not Available'}
                            </Button>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </div>
    )
}