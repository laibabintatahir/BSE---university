'use client'

import { useEffect, useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from 'next/link'

// Simulated API call
const fetchCourseDetails = async (courseId: string) => {
    // In a real application, you would fetch this data from your API
    return {
        id: courseId,
        name: "Introduction to Computer Science",
        description: "A comprehensive introduction to the fundamental concepts of computer science.",
        code: "CS101",
        credits: 3,
        teacherName: "John Doe",
        materials: [
            { id: "1", name: "Syllabus", type: "pdf" },
            { id: "2", name: "Lecture Notes Week 1", type: "pdf" },
            { id: "3", name: "Programming Assignment 1", type: "zip" },
        ]
    }
}

export default function CourseDetailsPage({ params }: { params: { courseId: string } }) {
    interface Course {
        id: string;
        name: string;
        description: string;
        code: string;
        credits: number;
        teacherName: string;
        materials: { id: string; name: string; type: string; }[];
    }

    const [courseData, setCourseData] = useState<Course | null>(null)

    useEffect(() => {
        const loadCourseData = async () => {
            const data = await fetchCourseDetails(params.courseId)
            setCourseData(data)
        }
        loadCourseData()
    }, [params.courseId])

    if (!courseData) {
        return <div>Loading...</div>
    }

    return (
        <div className="container mx-auto py-10">
            <Card>
                <CardHeader>
                    <CardTitle>{courseData.name}</CardTitle>
                    <CardDescription>{courseData.code} - {courseData.credits} credits</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p>{courseData.description}</p>
                    <p><strong>Teacher:</strong> {courseData.teacherName}</p>
                    <div>
                        <h3 className="text-lg font-semibold mb-2">Course Materials</h3>
                        <ul className="list-disc pl-5">
                            {courseData.materials.map((material) => (
                                <li key={material.id}>{material.name} ({material.type})</li>
                            ))}
                        </ul>
                    </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                    <Button variant="outline" asChild>
                        <Link href={`/courses/edit/${courseData.id}`}>Edit Course</Link>
                    </Button>
                    <Button variant="outline">Manage Materials</Button>
                </CardFooter>
            </Card>
        </div>
    )
}

