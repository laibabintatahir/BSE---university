'use client'
import { CourseForm } from "@/components/admin/course/course-form"

export default function CreateCoursePage() {
    const handleSubmit = (data: any) => {
        // Here you would typically send the data to your API
        console.log(data)
    }

    return (
        <div className="container mx-auto py-10">
            <h1 className="text-3xl font-bold mb-6">Create New Course</h1>
            <CourseForm onSubmit={handleSubmit} />
        </div>
    )
}

