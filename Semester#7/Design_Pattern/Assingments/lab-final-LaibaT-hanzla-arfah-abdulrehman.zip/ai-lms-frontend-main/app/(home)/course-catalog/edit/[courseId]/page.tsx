'use client'

import { useEffect, useState } from 'react'
import { CourseForm } from "@/components/admin/course/course-form"

// Simulated API call
const fetchCourseData = async (courseId: string) => {
    // In a real application, you would fetch this data from your API
    return {
        id: courseId,
        name: "Introduction to Computer Science",
        description: "A comprehensive introduction to the fundamental concepts of computer science.",
        code: "CS101",
        credits: 3,
    }
}

export default function EditCoursePage({ params }: { params: { courseId: string } }) {
    const [courseData, setCourseData] = useState<{ id: string; name: string; description: string; code: string; credits: number } | null>(null)

    useEffect(() => {
        const loadCourseData = async () => {
            const data = await fetchCourseData(params.courseId)
            setCourseData(data)
        }
        loadCourseData()
    }, [params.courseId])

    const handleSubmit = (data: any) => {
        // Here you would typically send the updated data to your API
        console.log(data)
    }

    if (!courseData) {
        return <div>Loading...</div>
    }

    return (
        <div className="container mx-auto">
            <h1 className="text-3xl font-bold mb-6">Edit Course</h1>
            <CourseForm initialData={courseData} onSubmit={handleSubmit} />
        </div>
    )
}

