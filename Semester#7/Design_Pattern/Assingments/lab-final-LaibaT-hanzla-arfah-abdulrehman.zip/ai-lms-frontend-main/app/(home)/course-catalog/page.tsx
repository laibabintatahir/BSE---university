import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { CourseCard } from "@/components/admin/course/course-card"

// Simulated API data
const courses = [
    { id: "1", name: "Mathematics", description: "Advanced mathematics course", teacherName: "John Doe" },
    { id: "2", name: "Physics", description: "Introductory physics course", teacherName: "Jane Smith" },
    { id: "3", name: "Chemistry", description: "General chemistry course", teacherName: "Bob Johnson" },
]

export default function CoursesPage() {
    return (
        <div className="container mx-auto py-10">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">Courses</h1>
                <Button asChild>
                    <Link href="/course-catalog/create">Create New Course</Link>
                </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {courses.map((course) => (
                    <CourseCard key={course.id} {...course} />
                ))}
            </div>
        </div>
    )
}

