'use client'
import { Assignment } from "@/types"
import { AssignmentCard } from "@/components/assignments/assignment-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"

// This would normally come from your API
const mockAssignments: Assignment[] = [
  {
    id: "1",
    title: "Introduction to React",
    course: "Web Development",
    dueDate: "2024-01-15",
    status: "ungraded",
    aiGrading: true,
    rubrics: ["Code Quality", "Documentation"],
    content: "Build a simple React application",
    totalMarks: 100
  },
  {
    id: "1",
    title: "Introduction to React",
    course: "Web Development",
    dueDate: "2024-01-15",
    status: "ungraded",
    aiGrading: true,
    rubrics: ["Code Quality", "Documentation"],
    content: "Build a simple React application",
    totalMarks: 100
  },
  {
    id: "1",
    title: "Introduction to React",
    course: "Web Development",
    dueDate: "2024-01-15",
    status: "graded",
    aiGrading: true,
    rubrics: ["Code Quality", "Documentation"],
    content: "Build a simple React application",
    totalMarks: 100
  },
  // Add more mock assignments...
]

export default function AssignmentsPage() {
  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Assignments</h1>
        <Link href="/assignments/create">
          <Button>Create Assignment</Button>
        </Link>
      </div>
      
      <div className="flex gap-4 mb-6">
        <Input 
          placeholder="Search assignments..." 
          className="max-w-sm"
        />
        <Button variant="outline">Filter</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockAssignments.map((assignment) => (
          <AssignmentCard
            key={assignment.id}
            assignment={assignment}
            onAction={(action) => {
              console.log(`Action ${action} for assignment ${assignment.id}`)
            }}
          />
        ))}
      </div>
    </div>
  )
}

    