import { CreateAssignmentForm } from "@/components/assignments/create-assignment-form"

export default function CreateAssignmentPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Create Assignment</h1>
      <CreateAssignmentForm />
    </div>
  )
}

