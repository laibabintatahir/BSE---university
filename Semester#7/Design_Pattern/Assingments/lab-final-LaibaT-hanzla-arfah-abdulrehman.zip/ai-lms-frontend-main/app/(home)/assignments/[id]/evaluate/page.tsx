import { EvaluateAssignmentForm } from "@/components/assignments/evaluate-assignment-form"

interface PageProps {
  params: {
    id: string
  }
}

export default function EvaluateAssignmentPage({ params }: PageProps) {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Evaluate Assignment</h1>
      <EvaluateAssignmentForm assignmentId={params.id} />
    </div>
  )
}

