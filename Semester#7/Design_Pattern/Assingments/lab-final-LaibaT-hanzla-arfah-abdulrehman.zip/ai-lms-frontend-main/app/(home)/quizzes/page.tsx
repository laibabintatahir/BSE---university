'use client'
import { Quiz } from "@/types"
import { QuizCard } from "@/components/quizzez/quiz-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"

// Mock data - would normally come from your API
const mockQuizzes: Quiz[] = [
  {
    id: "1",
    title: "React Fundamentals",
    course: "Web Development",
    dueDate: "2024-01-15",
    status: "ungraded",
    aiGrading: true,
    rubrics: ["Concept Understanding", "Implementation"],
    questionTypes: ["mcq", "short"],
    questions: [],
    totalMarks: 50
  },
  {
    id: "2",
    title: "SQL Basics",
    course: "Database Systems",
    dueDate: "2024-01-20",
    status: "ai-graded",
    aiGrading: true,
    rubrics: ["Query Writing", "Optimization"],
    questionTypes: ["mcq", "fitb"],
    questions: [],
    totalMarks: 30
  }
]

export default function QuizzesPage() {
  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Quizzes</h1>
        <Link href="/quizzes/create">
          <Button>Create Quiz</Button>
        </Link>
      </div>
      
      <div className="flex gap-4 mb-6">
        <Input 
          placeholder="Search quizzes..." 
          className="max-w-sm"
        />
        <Button variant="outline">Filter</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockQuizzes.map((quiz) => (
          <QuizCard
            key={quiz.id}
            quiz={quiz}
            onAction={(action) => {
              console.log(`Action ${action} for quiz ${quiz.id}`)
            }}
          />
        ))}
      </div>
    </div>
  )
}

