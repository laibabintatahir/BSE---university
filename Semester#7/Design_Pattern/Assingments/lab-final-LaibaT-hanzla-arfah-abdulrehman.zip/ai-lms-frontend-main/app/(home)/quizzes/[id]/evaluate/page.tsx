import { EvaluateQuizForm } from "@/components/quizzez/evaluate-quiz-form"

interface PageProps {
  params: {
    id: string
  }
}

export default function EvaluateQuizPage({ params }: PageProps) {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Evaluate Quiz</h1>
      <EvaluateQuizForm quizId={params.id} />
    </div>
  )
}

