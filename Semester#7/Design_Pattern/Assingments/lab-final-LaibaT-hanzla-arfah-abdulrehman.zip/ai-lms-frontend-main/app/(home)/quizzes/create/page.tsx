import { CreateQuizForm } from "@/components/quizzez/create-quiz-form"

export default function CreateQuizPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Create Quiz</h1>
      <CreateQuizForm />
    </div>
  )
}

