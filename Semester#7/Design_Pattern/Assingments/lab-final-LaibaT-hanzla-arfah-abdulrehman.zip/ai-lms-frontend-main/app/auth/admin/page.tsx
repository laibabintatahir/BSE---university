import { auth } from '@/auth'
import { AdminAuthForm } from '@/components/auth/admin-auth-form'
import AdminSideInfo from '@/components/auth/admin-sideinfo'
import SideInfo from '@/components/auth/sideinfo'
import { SigninForm } from '@/components/auth/signin-form'
import { redirect } from 'next/navigation'
import React from 'react'

const SigninPage = async () => {

    const session = await auth();
    if (session?.user) {
        redirect('/')
    }
    return (
        <AdminSideInfo>
            <AdminAuthForm />
        </AdminSideInfo>
    )
}

export default SigninPage