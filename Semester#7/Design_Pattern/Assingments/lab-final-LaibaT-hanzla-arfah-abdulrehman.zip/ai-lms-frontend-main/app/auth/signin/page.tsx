import { auth } from '@/auth'
import SideInfo from '@/components/auth/sideinfo'
import { SigninForm } from '@/components/auth/signin-form'
import { redirect } from 'next/navigation'
import React from 'react'

const SigninPage = async () => {

    const session = await auth();
    if (session?.user) {
        redirect('/')
    }
    return (
        <SideInfo>
            <SigninForm />
        </SideInfo>
    )
}

export default SigninPage