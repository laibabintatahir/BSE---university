import type { Metadata } from "next";
import "./globals.css";
import { Ubuntu } from 'next/font/google'
import { Toaster } from "react-hot-toast";
import { SessionProvider } from "next-auth/react";

export const metadata: Metadata = {
  title: "ClassEdge - AI Assisted LMS",
  description: "ClassEdge is an AI-assisted Learning Management System that provides a personalized learning experience for students and educators.",
};

const ubuntu = Ubuntu({
  weight: ['400', '500', '700'],
  subsets: ['latin']
})

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`antialiased ${ubuntu.className}`}
      >
        <SessionProvider>
          {children}
        </SessionProvider>
        <Toaster position="bottom-right" />
      </body>
    </html>
  );
}
