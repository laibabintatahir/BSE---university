﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(WheelCollider))]
public class WheelSkid : MonoBehaviour
{
	[SerializeField]
	private Rigidbody rb;
	[SerializeField]
	private Skidmarks skidmarksController;

	private WheelCollider wheelCollider;
	private WheelHit wheelHitInfo;

	private const float SKID_FX_SPEED = 0.5f; // Min side slip speed to start showing a skid
	private const float MAX_SKID_INTENSITY = 20.0f; // Max intensity for skid marks
	private const float DRIFT_THRESHOLD = 5.0f; // Min sideways speed to qualify as a drift
	private const float SCORE_MULTIPLIER = 10.0f; // Multiplier for drift score scaling

	private int lastSkid = -1;
	private float driftMultiplier = 0f;
	private float score = 0f;

	private float lastFixedUpdateTime;

	public TMPro.TMP_Text scoreText;

	void Update()
	{
		scoreText.text = $"Score: {score:F2}";
	}
	protected void Awake()
	{
		wheelCollider = GetComponent<WheelCollider>();
		lastFixedUpdateTime = Time.time;
	}

	protected void FixedUpdate()
	{
		lastFixedUpdateTime = Time.time;
	}

	protected void LateUpdate()
	{
		if (wheelCollider.GetGroundHit(out wheelHitInfo))
		{
			Vector3 localVelocity = transform.InverseTransformDirection(rb.linearVelocity);
			float skidTotal = Mathf.Abs(localVelocity.x);

			// Drift detection
			if (skidTotal > DRIFT_THRESHOLD)
			{
				driftMultiplier = Mathf.Clamp01(skidTotal / MAX_SKID_INTENSITY);
				score += driftMultiplier * SCORE_MULTIPLIER * Time.deltaTime;
			}
			else
			{
				driftMultiplier = 0f; // No drifting
			}

			// Handle skid marks
			float wheelAngularVelocity = wheelCollider.radius * ((2 * Mathf.PI * wheelCollider.rpm) / 60);
			float carForwardVel = Vector3.Dot(rb.linearVelocity, transform.forward);
			float wheelSpin = Mathf.Abs(carForwardVel - wheelAngularVelocity) * 10.0f;

			skidTotal += wheelSpin;

			if (skidTotal >= SKID_FX_SPEED)
			{
				float intensity = Mathf.Clamp01(skidTotal / MAX_SKID_INTENSITY);
				Vector3 skidPoint = wheelHitInfo.point + (rb.linearVelocity * (Time.time - lastFixedUpdateTime));
				lastSkid = skidmarksController.AddSkidMark(skidPoint, wheelHitInfo.normal, intensity, lastSkid);
			}
			else
			{
				lastSkid = -1;
			}
		}
		else
		{
			driftMultiplier = 0f;
			lastSkid = -1;
		}

		// Debug the score and multiplier
		Debug.Log($"Score: {score:F2}, Drift Multiplier: {driftMultiplier:F2}");
	}
}