using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public void OnPlayerQuit()
    {
        // Save the score if the player chooses to quit mid-level
        if (ScoreManager.Instance != null)
        {
            ScoreManager.Instance.SaveScore();
        }

        // Load the score screen or main menu as desired
        SceneManager.LoadScene("ScoreScreen");
        Debug.Log("Player quit! Transitioning to Score Screen.");
    }
    // public void OnLevelComplete()
    // {
    //     // Save the score before transitioning
    //     if (ScoreManager.Instance != null)
    //     {
    //         ScoreManager.Instance.SaveScore();
    //     }

    //     // Load the score screen
    //     SceneManager.LoadScene("ScoreScreen");
    //     Debug.Log("Level complete! Transitioning to Score Screen.");
    // }
}
