using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    public void LoadSceneByName(string sceneName)
    {
        Time.timeScale = 1f; // Ensure time is resumed
        SceneManager.LoadScene(sceneName);
        Debug.Log($"Loading scene: {sceneName}");
    }
    public void QuitToMainMenu()
    {
        Time.timeScale = 1f; // Ensure time is resumed
        SceneManager.LoadScene("MainMenu");
        Debug.Log("Returning to Main Menu.");
    }

    public void GoToScoreBoard()
    {
        SceneManager.LoadScene("ScoreBoard");
        Debug.Log("Loading Score Board.");
    }
}
