using UnityEngine;

public class QuitDialogManager : MonoBehaviour
{
    public GameObject quitDialog;
    public void ToggleQuitDialog()
    {
        if (quitDialog != null)
        {
            bool isActive = quitDialog.activeSelf;
            quitDialog.SetActive(!isActive);

            Time.timeScale = isActive ? 1f : 0f;
        }
    }

    public void ConfirmQuit()
    {
        // Save the score and go to the score screen
        ScoreManager.Instance.SaveScore();
        ScoreManager.Instance.ResetCurrentScore();

        UnityEngine.SceneManagement.SceneManager.LoadScene("ScoreBoard");
    }

    public void CancelQuit()
    {
        Time.timeScale = 1f;
        quitDialog.SetActive(false);
    }
}
