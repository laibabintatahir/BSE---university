using UnityEngine;
using TMPro;

public class ScoreScreen : MonoBehaviour
{
    public TMP_Text level1HighScoreText;
    public TMP_Text level2HighScoreText;

    private void Start()
{
    float level1HighScore = PlayerPrefs.GetFloat("HighestScore_Level1", 0f);
    float level2HighScore = PlayerPrefs.GetFloat("HighestScore_Level2", 0f);

    Debug.Log($"[ScoreScreen] Level 1 High Score: {level1HighScore}");
    Debug.Log($"[ScoreScreen] Level 2 High Score: {level2HighScore}");

    level1HighScoreText.text = $"Level 1: {level1HighScore:F2}";
    level2HighScoreText.text = $"Level 2: {level2HighScore:F2}";
}

}
