using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
        public static ScoreManager Instance { get; private set; }

    [SerializeField]
    private TMP_Text scoreText; // In-level score text

    private float currentScore = 0f;
    private string currentLevel;

    private void Awake()
    {
        // Singleton pattern
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject); // Prevent duplicates
        }
    }

    private void Start()
    {
        // Detect current level on start
        currentLevel = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;

        // Initialize in-level score UI
        if (scoreText != null)
            UpdateScoreUI();
    }

    public void AddScore(float points)
    {
        // Update current score
        currentScore += points;

        // Update UI
        if (scoreText != null)
            UpdateScoreUI();
    }

    public void SaveScore()
{
    string highScoreKey = $"HighestScore_{currentLevel}";
    float highestScore = PlayerPrefs.GetFloat(highScoreKey, 0f);

    if (currentScore > highestScore)
    {
        PlayerPrefs.SetFloat(highScoreKey, currentScore);
        PlayerPrefs.Save(); // Save to disk
        Debug.Log($"[SaveScore] New high score for {currentLevel}: {currentScore}");
    }
    else
    {
        Debug.Log($"[SaveScore] Current score ({currentScore}) is less than highest score ({highestScore}) for {currentLevel}");
    }
}

    private void UpdateScoreUI()
    {
        scoreText.text = $"Score: {currentScore:F2}";
    }

    public float GetHighScore(string levelName)
    {
        return PlayerPrefs.GetFloat($"HighestScore_{levelName}", 0f);
    }

    public void ResetCurrentScore()
    {
        currentScore = 0f;
    }
}
