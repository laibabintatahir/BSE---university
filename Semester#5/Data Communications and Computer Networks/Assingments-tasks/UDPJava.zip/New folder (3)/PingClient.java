package com.example.udppingrtt;

import java.io.*;
import java.net.*;
import java.util.*;

public class PingClient {
    private static final String SERVER_IP = "localhost";
    private static final int SERVER_PORT = 8080;

    public static void main(String[] args) {
        DatagramSocket clientSocket = null;

        try {
            clientSocket = new DatagramSocket();
            clientSocket.setSoTimeout(1000); // 1 second timeout

            for (int i = 0; i < 10; i++) {
                sendPing(i, clientSocket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (clientSocket != null && !clientSocket.isClosed()) {
                clientSocket.close();
            }
        }
    }

    public static void sendPing(int sequenceNumber, DatagramSocket clientSocket) {
        try {
            InetAddress IPAddress = InetAddress.getByName(SERVER_IP);
            byte[] sendData = "PING".getBytes();
            byte[] receiveData = new byte[1024];

            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, SERVER_PORT);
            System.out.println("Sending Ping #" + sequenceNumber + " to " + SERVER_IP + ":" + SERVER_PORT);
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

            long startTime = System.currentTimeMillis();
            clientSocket.send(sendPacket);
            clientSocket.receive(receivePacket);

            long endTime = System.currentTimeMillis();
            long roundTripTime = endTime - startTime;

            String response = new String(receivePacket.getData(), 0, receivePacket.getLength());

            if (response.equals("PONG")) {
                System.out.println("Received PONG from server. RTT: " + roundTripTime + "ms");
            }
        } catch (SocketTimeoutException e) {
            System.out.println("Ping #" + sequenceNumber + " Request timed out.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
