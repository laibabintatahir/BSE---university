package com.example.udppingrtt;

import java.io.*;
import java.net.*;

public class PingServer {
    private static final int PORT = 8080;

    public static void main(String[] args) {
        DatagramSocket serverSocket = null;
        try {
            serverSocket = new DatagramSocket(PORT);
            byte[] receiveData = new byte[1024];
            byte[] sendData;

            System.out.println("PingServer started and listening on port " + PORT);

            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                serverSocket.receive(receivePacket);
                String request = new String(receivePacket.getData(), 0, receivePacket.getLength());

                if (request.equals("PING")) {
                    Thread.sleep(100); // Simulate a long-running operations
                    sendData = "PONG".getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, receivePacket.getAddress(), receivePacket.getPort());
                    serverSocket.send(sendPacket);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
        }
    }
}
