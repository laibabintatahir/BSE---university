import React, { Component } from "react";
import AboutHeader from "../components/AboutHeader";
class About extends Component{

    render()
    {
        return(
            <div>
              <AboutHeader/>  
    <section className="about">

<div className="row">
    <div className="about-col">
        <h3>Vision Statement:</h3>
        <p>
            Our vision is to create a world where education is accessible to all. We believe that everyone deserves the opportunity to learn and grow, regardless of their background or circumstances. Through our website, we aim to empower individuals and communities by providing high-quality, engaging educational content that inspires lifelong learning.  
              
            <br/>
            <br/>
            <span> <h3>Mission</h3></span> 
            
            <p>To help create a world where all nations are at peace with one another and capable of providing a good quality of life to their populations in a sustainable way, using modern scientific and technological resources.</p>
            
            </p>

        <a href="" class="btn2">EXPLORE MORE</a>
    </div>
    <div className="about-col"></div>
    <img src="images/about.png" alt=""/>
</div>

</section>

   
            
</div>
        );
    }
}
export default About;