import React, { Component } from "react";
import FooterHome from "../components/Hfooter";
import HeaderHome from "../components/Hheader";
class Home extends Component{

    render()
    {
        return(
            <div>
<HeaderHome/>
            <section className="course">
                <h1>Course We Offer</h1>
                <p>Campus Chronicles Course Catalog Portal is an information and assistance resource designed for the CC Faculty and Staff.</p>

                <div className="row">
                    <div className="course-col">
                        <h3>Intermediate</h3>
                        <p>Students will be well-prepared for entry-level positions in fields such as advertising, marketing, publishing, and web design, or they may choose to continue their education by pursuing a bachelor's degree in related field.</p>
                    </div>
                    <div className="course-col">
                        <h3>Becholars</h3>
                        <p>The Bachelor programs at Campus Chronicles is designed to provide students with a strong foundation in respective programs and prepare them for successful careers in a rapidly growing field.</p>
                    </div>
                    <div className="course-col">
                        <h3>Masters</h3>
                        <p>Faculty members and students are quite active in research in their respective fields. To encourage the research environment at CC, the management facilitates the faculty and students by providing facilities and incentives. </p>
                    </div>
                </div>
            </section >

            <section className="campus">
                <h1>
                    our campuses
                </h1>
                <p>
                    Enjoy the freedom of university studies, add on more knowledge, have fun studying, and experience the diversity at CC.
                </p>

                <div class="row">
                    <div class="campus-col">
                        <img src="images/cam2.png" />
                        <div class="layer">
                            <h3>Lahore</h3>
                        </div>
                    </div>

                    <div class="campus-col">
                        <img src="images/cam2.png" />
                        <div class="layer">
                            <h3>Islamabad</h3>
                        </div>
                    </div>
                    <div class="campus-col">
                        <img src="images/cam2.png" />
                        <div class="layer">
                            <h3>Abbottabad</h3>
                        </div>
                    </div>
                </div>
            </section>

            <section className="facilities">
                <h1>Our facilities</h1>
                <p>we provide best of the facilities</p>

                <div className="row">
                    <div className="facilities-col">
                        <img src="images/cafetria.png" alt="" />
                        <h3>Library</h3>
                        <p>Library at CC has more than 32000 books, wi-fi enabled computer work stations and access to HEC Digital Library e-books . Students and faculty have wide range of resources to gain extensive insight and knowledge. Library is also equipped with state of the art video conferencing room.</p>
                    </div>

                    <div class="facilities-col">
                        <img src="images/cafetria.png" alt="" />
                        <h3>Cafeteria</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic consequatur, architecto cum maiores consequuntur ratione eius soluta earum placeat, enim magni. Quam error in ad culpa, dolores eum quos voluptatem!</p>
                    </div>

                    <div class="facilities-col">
                        <img src="images/play.png" alt="" />
                        <h3>Student Societies</h3>
                        <p>There are various students’ societies on campus that you can be a part of such as Chronicles Literary Society, Aadrish- A Fine Arts Society, Dawaa Society, Chronicles Chemical Society, IEEE Student Branch, Society of Geoscientists, IET on Campus, Funkada- a performing arts society and many more.</p>
                    </div>

                </div>
            </section>

            <section className="testimonial">

                <h1>What our students says</h1>
                <p>Student brings in his or her own experiences and achievements along to make the campus life exuberant.</p>

                <div class="row">
                    <div class="testimonial-col">
                        <img src="images/xyz.png" alt="" />
                        <div>
                            <p>I recently completed the Bachelor of Business Administration program at Campus Chronicles. The program was challenging but also incredibly rewarding, and the professors were always available to offer support and guidance when I needed it.</p>
                            <h3>student abc</h3>
                        </div>

                    </div>

                    <div class="testimonial-col">
                        <img src="images/xyz.png" alt="" />
                        <div>
                            <p>I appreciated the sense of community at Campus Chronicles. The faculty and staff truly care about their students, and there are always opportunities to get involved in clubs, organizations, and events on campus.</p>
                            <h3>student xyz</h3>
                        </div>
                    </div>

                </div>

            </section>

            <section className="cta">
                <h1>Enroll for various online courses</h1>
                <a href="" class="cta-btn">CONTACT US</a>
            </section>

<FooterHome/>
        </div>

        );
    }
}
export default Home;