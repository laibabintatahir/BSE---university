import React, { Component } from "react";
import BlogHeader from "../components/BlogHeader";
import FooterHome from "../components/Hfooter";
class Blog extends Component{

    render()
    {
        return(
<div>
    <BlogHeader/>
<section class="blog-content">
    <div class="row">
        <div class="blog-left">
            <h2>Our Certificates & Online Programs For 2023</h2>
            <p>At Campus Chronicles, we understand that many of our students have busy schedules and may not be able to attend classes on campus. That's why we offer a variety of certificate programs and online courses that allow you to advance your education and career from anywhere, at any time.
                <br/>
                <br/>
                Our online programs include a range of courses and degrees that you can complete entirely online, without ever setting foot on campus. Whether you're interested in earning a bachelor's degree in business administration or completing a certificate program in computer science, our online programs are designed to provide you with a flexible and convenient way to further your education.

                <br/><br/>
                Our certificates are also a great way to gain new skills and knowledge in a specific field, without committing to a full degree program. We offer certificates in a variety of subjects, including data analytics, digital marketing, and project management, among others. These certificates can be completed in as little as a few months and are a great way to enhance your resume and advance your career.
                <br/><br/>
                At Campus Chronicles, we're proud to offer a range of certificates and online programs that provide our students with the skills and knowledge they need to succeed in today's rapidly changing world. If you're ready to expand your horizons and advance your career, we invite you to explore our certificate and online program offerings today.
                <br/>
            </p>
       
            <div class="commemt">
                <h3>Leave a comment</h3>

                <form class="comment-form">
                    <input type="text" placeholder="Name"/>
                    <input type="text" placeholder="Email"/>

                    <textarea rows="5" placeholder="your comment"></textarea>

                    <button type="submit" class="btn3">Post Comment</button>
                </form>
            </div>
        </div>
        <div class="blog-right">
            <h3>Some Statistics</h3>
            <div>
                <span>Enrolled Students</span>
                <span>33,744</span>
            </div>
            <div>
                <span>Degree Program</span>
                <span>107</span>
            </div>
            <div>
                <span>MS Students</span>
                <span>5000</span>
            </div>
            <div>

                <span>Degree Programs</span>
                <span>100</span>
            </div>
        </div>
    </div>
</section>
     <FooterHome/>       
</div>
        );
    }
}
export default Blog;