import React from 'react';
import './App.css';
import { Routes, Route, BrowserRouter } from 'react-router-dom';
import Home from './pages/Home';
import Courses from './pages/Courses';
import Blog from './pages/Blog';
import About from './pages/About';

function App() {
  return  (
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='blog' element={<Blog/>}/>
        <Route path='courses' element={<Courses/>}/>
        <Route path='about' element={<About/>}/>
        <Route path='contact' element={<Home/>}/>
  </Routes> 
  );
}
export default App;
