
import { BrowserRouter } from 'react-router-dom';
import { Link } from "react-router-dom";
const AboutHeader=()=>{

    return(
        <div>
    <section className="About-header">
           <nav>
            <a href="index.html">e-learning</a>
            <div class="nav-links">
                <ul>
                    <li><Link to='/'>Home</Link></li>
                    <li><Link to='/Courses'>Courses</Link></li>
                    <li><Link to='/Blog'>Blog</Link></li>
                    <li><Link to='/About'>About</Link></li>
                    <li><Link to='/Contact'>Contact</Link></li>

                </ul>
            </div>
        </nav>     
        <h1>About Us</h1>
    </section>
        </div>
    );
}
export default AboutHeader ;