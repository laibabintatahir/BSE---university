
import { BrowserRouter } from 'react-router-dom';
import { Link } from "react-router-dom";
const HeaderHome=()=>{

    return(

        <div>
           <section className="header">
           <nav>
            <a href="index.html">e-learning</a>
            <div class="nav-links">
                <ul>
                    <li><Link to='/'>Home</Link></li>
                    <li><Link to='/Courses'>Courses</Link></li>
                    <li><Link to='/Blog'>Blog</Link></li>
                    <li><Link to='/About'>About</Link></li>
                    <li><Link to='/Contact'>Contact</Link></li>

                </ul>
            </div>
        </nav>
            <div className="text-box">
            <h1>Campus Chronicles</h1>
            <p>To become a leading institution of higher education that prepares students for a lifetime <br/> of learning, leadership, and service to their communities.</p>

            <a href="" className="btn1">visit us to know more</a>
        </div>
    </section>
        </div>
    );
}
export default HeaderHome ;