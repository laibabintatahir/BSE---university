const FooterHome=()=>{

    return(
        <div>

    <section className="footer">
        <h4>About Us</h4>
        <p> We generates and preserves knowledge, understanding and creativity by instigating enquiry, conducting high-quality research that benefits students,
        <br/>scholars, and communities across the country, the Muslim Ummah and the World, at large.
        </p>
        <div>
        <p>copyright @ Campus Chronicles website

        </p>
        </div>

    </section>
    
        </div>
    );
}
export default FooterHome ;