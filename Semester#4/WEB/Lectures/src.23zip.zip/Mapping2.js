import { useState } from "react";

const Mapping2 = () => {    

    const [students, setStudents] = useState([
        { id: 1, name: 'John', age: 20 },
        { id: 2, name: 'Peter', age: 21 },
        { id: 3, name: 'Mark', age: 22 },
        { id: 4, name: 'James', age: 23 },
    ]);

    const handleDelete = (id) => {
        console.log("clicked.");
        console.log(id);
        const newStudents = students.filter((student) => student.id !== id);
        setStudents(newStudents);
     }
    return (
        <div>
            <h1>Mapping - example 2</h1>

          {
            students.map((student) => (
                <div>
                     <h2>Student ID: {student.id}</h2>
                    <h2>Student Name: {student.name}</h2>
                    <h2>Student Age: {student.age}</h2>
                    <button onClick={e => handleDelete(student.id)}>Delete Record</button>
                </div>   
            )    
            )
          }


        </div>
    )
}
export default Mapping2;    