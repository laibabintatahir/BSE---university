const Mapping = () => {

  const age = [18,19,20,21,22];  

  return (
    <div>
      <h1>Showing age...</h1>

        {
            age.map(ageData =>
                <h1>Age: {ageData}</h1>
            )
        }

    </div>
  );
}

export default Mapping;