import Mapping2 from './Mapping2';

function App() {
  return (
    <div>
      <Mapping2 />
    </div>
  );
}

export default App;
