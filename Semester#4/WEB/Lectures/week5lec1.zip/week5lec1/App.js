
// import Signup from "./signup"
// import Filehandling  from './Filehandling'
// import Checkout from './Checkout';
// import Service from './Service';
// import Student from "./Student";
    // import Home from '.../ADMS/Homepage'
// import Home from '.../ADMS/Admissionform/home'
// import Home from '.../ADMS/Feestructure/Home'
import Navigation from './Navigation';
// import Pra from './practicse/pra';

import { Routes, Route } from "react-router-dom";
import Memberships from "./Memberships";
import ContactUs from "./ContactUs";
import Services from './Services';


function App()
 {
  return (


<div>
  
  <Services />
    <Navigation />

    <Routes>

      <Route  path="/memberships" element={<Memberships />} />
      <Route  path="/contact" element={<ContactUs />} />


    </Routes>


  {/* <Student/> */}
  {/* <Signup/>  */}
  {/* <Filehandling/> */}
  {/* <Service/> */}
{/* <Checkout/> */}

{/* <Home/> */}

{/* <Pra/> */}


</div>
   );

  }

export default App;
