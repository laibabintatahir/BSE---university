const Membership = () => {
    return (
        <div>
            <h1>I am a Membership component.</h1>
        </div>
    )
}

export default Membership;