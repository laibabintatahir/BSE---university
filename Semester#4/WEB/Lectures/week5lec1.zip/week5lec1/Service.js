
import {useState} from "react"
import Checkout from "./Checkout";
function Service() {
    const [memberShip,setmembership]=useState("free plan")
    const [price,serprice] =useState(0)
function handleMembershipPlan()
{
    setmembership("platinumPlan");
    setprice(10);
}
  return (
    <div>
     <h1>services plan</h1>
     <h2>{memberShip}</h2>
    <button onClick={handleMembershipPlan}> changeservices</button>
    
    <Checkout serviceName = {memberShip } serviceplan={price}/>
    </div>
  )
}
export default Service;
