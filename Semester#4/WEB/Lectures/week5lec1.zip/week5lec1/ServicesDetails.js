const ServicesDetails = ({ sfee, sdur, changeFee }) => {
    return (
        <div>
            <h1>I am ServicesDetails Component. </h1>
            <h2>Service Fee : {sfee} </h2>
            <h2>Services Duration : {sdur}</h2>
            <button onClick={changeFee}>Change Fee from services Details</button>
        </div>
    )
}

export default ServicesDetails;