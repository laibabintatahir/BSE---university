import { Link } from "react-router-dom";

const Navigation = () => {
    return (
        <div>
            <Link to="/memberships">Memberships</Link>
            <Link to="/contact">Contact Us</Link>
        </div>
    );
}

export default Navigation;