import { useState } from "react";
import ServicesDetails from "./ServicesDetails";

const Services = () => {

    const [servicesFee, setServicesFee] = useState(1000);
    const [servicesDuration, setServicesDuration] = useState(365);

    const handleFee = () => {
        setServicesFee(2500);
    }

    return (
        <div>
            <h1>I am Services Component. </h1>
            <ServicesDetails  sfee = {servicesFee}              
                              sdur = {servicesDuration} 
                              changeFee = {handleFee} />

            <button onClick={handleFee}>Change Services Fee</button>
        </div>
    )
}

export default Services;
