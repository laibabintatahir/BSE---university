const ALogin  = () => {

    const loginHandler  = () => {
        console.log("Calling longin handler from arrow comp...");
    }

    return (
        <div>
            <h1>Logging from Arrow component...</h1>
            <button onClick={loginHandler}>
                Arrow Button
            </button>
        </div>
    ); 
}

export default ALogin;