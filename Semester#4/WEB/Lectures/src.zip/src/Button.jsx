function Button() {
  return <button>Click</button>;
}
export default Button;
