import { Component } from "react";

class CLogin extends Component {

    //between state and render method

    loginHandler  = () => {
        console.log("Calling longin handler from class comp...");
    }

    render () {
        return (
            <div>
                <h1>Logging from Class component...</h1>
                <button onClick={this.loginHandler}>
                    Class Button
                </button>
            </div>
        );
    }
}

export default CLogin;