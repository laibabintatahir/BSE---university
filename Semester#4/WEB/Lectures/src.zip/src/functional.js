import "./mycss.css                                                                                                                           ";

function FLogin () {

    function loginHandler () {
        console.log("Calling longin handler from funct comp...");
    }

    const myStyle = {
        color: "red",
        backgroundColor: "orange"
    }
    return (
        <div>
            <h1 style={{ backgroundColor : "gray" }}>Logging from functional component...</h1>
            <h2 style={myStyle}>Internal style in functional component.</h2>
            <h3>External from functioanl component.</h3>
            <button onClick={loginHandler}>
                Functional Button
            </button>
        </div>
    );
}

export default FLogin;