import ALogin from "./arrowComp";
import CLogin from "./classComp";
import FLogin from "./functional";

function App() {
  return (
    <div>
      <FLogin /> 
      <ALogin />
      <CLogin />
    </div>
  );
}

export default App;
